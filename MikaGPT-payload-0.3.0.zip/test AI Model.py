"""MikaGPT: een kleine assistent voor vragen, taken, notities en rekenen."""

import ast
import json
import math
import operator
import os
import random
import sys
from datetime import datetime
from difflib import SequenceMatcher
from pathlib import Path

from mikagpt_features import Functies, bereid_gegevens_voor
from mikagpt_lokaal import antwoord_van_model
from mikagpt_taal import antwoord_op_kort_bericht, antwoord_op_onbekend, soort_kort_antwoord, verwerk_taalvraag
from mikagpt_weer import herken_weervraag, weerbericht
from mikagpt_wikipedia import antwoord_van_wikipedia


# Taken, notities en je naam worden naast het programma bewaard. Bij de
# zelfstandige Windows-versie is dat de map waar MikaGPT.exe staat.
PROGRAMMAMAP = (Path(sys.executable).resolve().parent if getattr(sys, "frozen", False)
                else Path(__file__).resolve().parent)
GEGEVENSBESTAND = Path(os.environ.get("MIKAGPT_DATA_BESTAND", PROGRAMMAMAP / "mikagpt_data.json"))
PROJECTMAP = PROGRAMMAMAP / "projecten"

# Elke bekende zin hoort bij een soort antwoord.
BEKENDE_ZINNEN = {
    "help": "hulp",
    "hulp": "hulp",
    "hallo": "begroeting",
    "hoi": "begroeting",
    "hey": "begroeting",
    "goedendag": "begroeting",
    "goedemorgen": "begroeting",
    "goedemiddag": "begroeting",
    "goedenavond": "begroeting",
    "hoe heet ik": "jouw_naam",
    "wat is mijn naam": "jouw_naam",
    "hoe gaat het": "hoe_gaat_het",
    "hoe gaat het met je": "hoe_gaat_het",
    "alles goed": "hoe_gaat_het",
    "wie ben je": "naam_chatbot",
    "wat is je naam": "naam_chatbot",
    "bedankt": "bedankt",
    "dankje": "bedankt",
    "thanks": "bedankt",
    "wat kun je doen": "mogelijkheden",
    "wat kan je doen": "mogelijkheden",
    "hoe laat is het": "tijd",
    "welke datum is het": "datum",
    "stop": "afsluiten",
    "tot ziens": "afsluiten",
    "doei": "afsluiten",
}

FEITJES = [
    "De aarde draait om de zon.",
    "De maan geeft zelf geen licht; ze weerkaatst zonlicht.",
    "Een driehoek heeft drie zijden.",
    "Een dolfijn is een zoogdier.",
    "Een bij is een insect.",
    "Planten gebruiken zonlicht bij fotosynthese.",
]
FEITJE_OPDRACHTEN = {"feitje", "vertel een feitje", "geef een feitje", "heb je een feitje"}


def kies_anders(opties, vorig_antwoord=""):
    """Kies willekeurig, maar herhaal niet meteen hetzelfde antwoord."""
    andere = [optie for optie in opties if optie != vorig_antwoord]
    return random.choice(andere or opties)


def volgend_feitje(beschikbare, vorig_feitje=""):
    """Gebruik alle feitjes een keer voordat er eentje terugkomt."""
    if not beschikbare:
        beschikbare.extend(FEITJES)
        random.shuffle(beschikbare)
        if beschikbare[-1] == vorig_feitje:
            beschikbare[-1], beschikbare[0] = beschikbare[0], beschikbare[-1]
    return beschikbare.pop()


def laad_gegevens():
    """Lees eerder opgeslagen gegevens, of begin met lSege lijsten."""
    if not GEGEVENSBESTAND.exists():
        gegevens = {"naam": None, "taken": [], "notities": []}
    else:
        gegevens = json.loads(GEGEVENSBESTAND.read_text(encoding="utf-8"))
    return bereid_gegevens_voor(gegevens)


def bewaar_gegevens(gegevens):
    """Bewaar gegevens eerst tijdelijk, zodat het bestand heel blijft."""
    tijdelijk = GEGEVENSBESTAND.with_suffix(".tmp")
    tijdelijk.write_text(
        json.dumps(gegevens, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    tijdelijk.replace(GEGEVENSBESTAND)


def bepaal_bedoeling(bericht):
    """Vergelijk na een exacte match ieder woord met bekende zinnen."""
    if bericht in BEKENDE_ZINNEN:
        return BEKENDE_ZINNEN[bericht]

    woorden = bericht.split()
    beste_bedoeling = None
    beste_score = 0
    for zin, bedoeling in BEKENDE_ZINNEN.items():
        bekende_woorden = zin.split()
        if len(woorden) != len(bekende_woorden):
            continue

        scores = []
        for woord, bekend_woord in zip(woorden, bekende_woorden):
            score = SequenceMatcher(None, woord, bekend_woord).ratio()
            # Stoppen vraagt een sterkere overeenkomst om vergissingen te vermijden.
            grens = 0.85 if bedoeling == "afsluiten" else 0.70
            if score < grens:
                break
            scores.append(score)

        if scores and len(scores) == len(woorden):
            gemiddelde = sum(scores) / len(scores)
            if gemiddelde > beste_score:
                beste_score = gemiddelde
                beste_bedoeling = bedoeling
    return beste_bedoeling


def bereken(expressie):
    """Reken met +, -, * en / zonder Python-code uit de invoer te draaien."""
    if len(expressie) > 100:
        raise ValueError("De som is te lang.")

    bewerkingen = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
    }

    def waarde(knoop):
        if isinstance(knoop, ast.Expression):
            return waarde(knoop.body)
        if isinstance(knoop, ast.Constant) and type(knoop.value) in (int, float):
            getal = knoop.value
        elif isinstance(knoop, ast.UnaryOp) and isinstance(knoop.op, (ast.UAdd, ast.USub)):
            getal = waarde(knoop.operand)
            if isinstance(knoop.op, ast.USub):
                getal = -getal
        elif isinstance(knoop, ast.BinOp) and type(knoop.op) in bewerkingen:
            getal = bewerkingen[type(knoop.op)](waarde(knoop.left), waarde(knoop.right))
        else:
            raise ValueError("Gebruik alleen getallen, haakjes, +, -, * en /.")

        if not math.isfinite(getal) or abs(getal) > 1_000_000_000_000:
            raise ValueError("De uitkomst is te groot.")
        return getal

    try:
        return waarde(ast.parse(expressie.replace(",", "."), mode="eval"))
    except (SyntaxError, ZeroDivisionError, OverflowError) as fout:
        raise ValueError("Deze som kan ik niet berekenen.") from fout


def toon_hulp():
    print("AI: Je kunt dit typen:")
    print("  ik heet Mika          - onthoud mijn naam")
    print("  taak: melk kopen      - voeg een taak toe")
    print("  taken                 - bekijk je taken")
    print("  klaar: 1              - markeer taak 1 als klaar")
    print("  verwijder taak: 1     - verwijder taak 1")
    print("  notitie: een idee     - bewaar een notitie")
    print("  notities              - bekijk je notities")
    print("  verwijder notitie: 1  - verwijder notitie 1")
    print("  reken 2 + 3 * 4       - bereken een som")
    print("  hoe laat is het?      - toon de tijd")
    print("  feitje                - vertel een feitje; reageer met ok, ja of nee")
    print("  onthoud: ik hou van thee  - bewaar een voorkeur")
    print("  geheugen / vergeet: 1    - bekijk of verwijder een voorkeur")
    print("  gesprek / wis gesprekken  - bekijk of wis eerdere berichten")
    print("  leer: vraag | antwoord   - leer MikaGPT een nieuw antwoord")
    print("  leer woord: fles | een houder voor vloeistof")
    print("  leer eigenschap: fles | inhoud | verschilt per fles")
    print("  wat betekent fles / hoe groot is een fles")
    print("  maak een zin met fles / vergeet woord: fles")
    print("  frans leer: quelque chose | iets - voeg een Frans woordpaar toe")
    print("  frans woorden             - bekijk de Franse woordenlijst")
    print("  leren f-n: quelque chose | morgen | iets - kies Nederlands")
    print("  leren n-f: iets | demain | quelque chose - kies Frans")
    print("  overhoren f-n: quelque chose - typ Nederlands")
    print("  overhoren n-f: iets      - typ Frans")
    print("  project nieuw: School    - maak een project")
    print("  projecten               - bekijk je projecten")
    print("  doel: maak een website   - maak een plan met stappen")
    print("  doelmodus               - vertel wat je wilt bereiken")
    print("  afspraak: 2026-10-01 15:00 | oefenen")
    print("  bestanden / tools        - bekijk bestanden of gereedschap")
    print("  zoek internet: sterren   - zoek via je browser na bevestiging")
    print("  open https://www.wikipedia.org - open een link in je browser")
    print("  website start: https://apps.noordhoff.nl/... - open een apart Chrome-venster")
    print("  website status / website sluit - lees scores of sluit het venster")
    print("  maak bestand: test.py | print('Hoi')")
    print("  controleer code: test.py - controleer Python-syntaxis")
    print("  leg code uit: test.py    - bekijk de opbouw van code")
    print("  test uitvoer: test.py | Hoi - vergelijk de uitvoer")
    print("  poster: titel | tekst    - maak een eenvoudige SVG-poster")
    print("  wat wordt het weer    - vraag daarna om welke plaats het gaat")
    print("  weer morgen in Utrecht - bekijk de verwachting voor morgen")
    print("  wat is de aarde?       - zoekt bij kennisvragen in Wikipedia en toont de bron")
    print("  doei / stop           - neem afscheid zonder het gesprek te wissen")


def wis_chat():
    """Wis het zichtbare gesprek en de terugscrollbare regels in de terminal."""
    if sys.stdout.isatty():
        print("\033[3J\033[2J\033[H", end="", flush=True)


def main():
    # Toon ook plaatsnamen en weertekens in de Windows-terminal.
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    try:
        gegevens = laad_gegevens()
    except (OSError, json.JSONDecodeError, ValueError):
        print("AI: Ik kan mikagpt_data.json niet lezen. Je bestaande gegevens zijn niet gewijzigd.")
        return

    functies = Functies(gegevens, bewaar_gegevens, PROJECTMAP)
    wacht_op_weerplaats = None
    laatste_feitje = ""
    beschikbare_feitjes = []
    feitje_context = None  # na_feitje, meer of leuk
    eerste_bericht = True
    print("AI: Hallo! Typ 'help' om te zien wat ik kan doen.")

    def vraag_aan_lokaal_model(vraag):
        """Geef vrije vragen de gespreksgeschiedenis en opgeslagen voorkeuren mee."""
        return antwoord_van_model(
            vraag, functies.project["gesprek"], gegevens["naam"],
            gegevens["antwoordstijl"], gegevens["voorkeuren"],
            gegevens["actief_project"],
        )

    # Blijf vragen lezen totdat iemand stopt of de invoer wordt gesloten.
    while True:
        for melding in functies.meld_herinneringen():
            print("AI: " + melding)
        try:
            invoer = input("Jij: ").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not invoer:
            print("AI: Typ een vraag of 'help'.")
            continue

        bericht = invoer.lower().rstrip("!?., ")
        if not bericht:
            print("AI: Typ een vraag of 'help'.")
            continue
        # Een instemming of afwijzing slaat op de vraag die nog openstaat.
        kort_antwoord = soort_kort_antwoord(bericht)
        if kort_antwoord is not None:
            gesprek = functies.project["gesprek"]
            vorige_antwoord = gesprek[-1]["antwoord"] if gesprek else ""
            if eerste_bericht:
                extra_antwoord = (
                    "Natuurlijk. Stel je vraag maar; je mag ook gewoon vertellen waar je hulp bij wilt."
                    if kort_antwoord == "ja" else
                    "Geen probleem. Vertel maar wanneer je ergens hulp bij wilt."
                )
            elif wacht_op_weerplaats is not None:
                if kort_antwoord == "nee":
                    wacht_op_weerplaats = None
                    extra_antwoord = "Prima, dan slaan we het weerbericht over."
                else:
                    extra_antwoord = "Welke plaats bedoel je? Noem bijvoorbeeld Utrecht, of typ 'annuleer'."
            elif functies.wacht_op_bevestiging is not None:
                if kort_antwoord == "nee":
                    functies.wacht_op_bevestiging = None
                    extra_antwoord = "Prima, ik heb de actie geannuleerd."
                else:
                    extra_antwoord = "Als je de actie wilt uitvoeren, typ dan 'bevestig'."
            elif functies.wacht_op_doel:
                if kort_antwoord == "nee":
                    functies.wacht_op_doel = False
                    extra_antwoord = "Prima, dan laten we dat doel even rusten."
                else:
                    extra_antwoord = "Vertel me in een zin wat je wilt bereiken."
            elif feitje_context == "na_feitje":
                if kort_antwoord == "nee":
                    extra_antwoord = kies_anders(["Prima, dan laten we de feitjes even rusten.",
                                                  "Geen probleem. Waar wil je het nu over hebben?"], vorige_antwoord)
                    feitje_context = None
                elif bericht in {"ja", "jazeker", "zeker", "tuurlijk", "natuurlijk", "graag", "ja graag"}:
                    laatste_feitje = volgend_feitje(beschikbare_feitjes, laatste_feitje)
                    extra_antwoord = laatste_feitje
                elif kort_antwoord == "twijfel":
                    extra_antwoord = "Geen haast. Wil je later nog een feitje horen?"
                    feitje_context = "meer"
                else:
                    feitje_context = random.choice(["meer", "leuk"])
                    opties = (["Wil je er nog een horen?", "Zal ik nog een feitje vertellen?",
                               "Ben je benieuwd naar nog een feitje?"] if feitje_context == "meer"
                              else ["Vond je het feitje leuk?", "Was dit een leuk feitje voor je?",
                                    "Sprak dit feitje je aan?"])
                    extra_antwoord = kies_anders(opties, vorige_antwoord)
            elif feitje_context in {"meer", "leuk"}:
                if kort_antwoord == "ja" and feitje_context == "meer":
                    laatste_feitje = volgend_feitje(beschikbare_feitjes, laatste_feitje)
                    extra_antwoord = laatste_feitje
                    feitje_context = "na_feitje"
                elif kort_antwoord == "ja" and bericht not in {"ok", "oke", "oké"}:
                    extra_antwoord = kies_anders(["Leuk! Wil je nog een feitje horen?",
                                                  "Fijn om te horen. Zal ik er nog een vertellen?"], vorige_antwoord)
                    feitje_context = "meer"
                elif kort_antwoord == "nee" and feitje_context == "meer":
                    extra_antwoord = kies_anders(["Prima, dan bewaren we de volgende voor later.",
                                                  "Geen probleem. Vertel maar wat je nu wilt doen."], vorige_antwoord)
                    feitje_context = None
                elif kort_antwoord == "nee":
                    extra_antwoord = "Jammer. Wil je een ander feitje proberen?"
                    feitje_context = "meer"
                elif kort_antwoord == "twijfel":
                    extra_antwoord = "Geen haast. Zeg maar 'ja' als je er nog een wilt."
                    feitje_context = "meer"
                else:
                    # 'Oké' op 'Vond je het leuk?' is neutrale feedback.
                    extra_antwoord = "Oké. Zal ik nog een ander feitje vertellen?"
                    feitje_context = "meer"
            else:
                modelvraag = invoer
                vorig = vorige_antwoord.casefold()
                if (kort_antwoord == "ja" and vorig.rstrip().endswith("?")
                        and ("wil je dat ik" in vorig or "zal ik" in vorig)):
                    modelvraag = (
                        "Ja. Voer uit wat je in je vorige bericht aanbood. "
                        "Geef nu het gevraagde resultaat op basis van ons gesprek, "
                        "zonder dezelfde vraag opnieuw te stellen."
                    )
                extra_antwoord = (vraag_aan_lokaal_model(modelvraag) if gesprek else None)
                if extra_antwoord is None:
                    extra_antwoord = antwoord_op_kort_bericht(bericht, vorige_antwoord)
            print("AI: " + extra_antwoord)
            try:
                functies.onthoud_gesprek(invoer, extra_antwoord)
            except OSError:
                print("AI: Ik kon dit gesprek niet bewaren.")
            eerste_bericht = False
            continue
        if not bericht.startswith("antwoord "):
            eerste_bericht = False
        if (bericht in FEITJE_OPDRACHTEN and wacht_op_weerplaats is None
                and not functies.wacht_op_doel and functies.wacht_op_bevestiging is None):
            laatste_feitje = volgend_feitje(beschikbare_feitjes, laatste_feitje)
            feitje_context = "na_feitje"
            print("AI: " + laatste_feitje)
            try:
                functies.onthoud_gesprek(invoer, laatste_feitje)
            except OSError:
                print("AI: Ik kon dit gesprek niet bewaren.")
            continue
        feitje_context = None
        bedoeling = bepaal_bedoeling(bericht)
        weervraag = herken_weervraag(invoer)
        # Stoppen blijft altijd mogelijk, ook na aangeleerde antwoorden.
        als_weerplaats = wacht_op_weerplaats is not None and bedoeling != "afsluiten"
        if als_weerplaats or weervraag is not None or bedoeling == "afsluiten":
            extra_antwoord = None
        else:
            extra_antwoord = functies.opdracht(invoer)
            if extra_antwoord is None and bedoeling is None:
                extra_antwoord = antwoord_van_wikipedia(
                    invoer, functies.project["gesprek"], gegevens["antwoordstijl"]
                )
            if extra_antwoord is None and bedoeling is None:
                extra_antwoord = verwerk_taalvraag(invoer, gegevens, bewaar_gegevens)
            # Een onbekend woord of voorwerp kan het lokale taalmodel uitleggen.
            if extra_antwoord and extra_antwoord.startswith(("Ik weet nog niet wat '", "Ik begrijp dat je naar")):
                lokaal_antwoord = vraag_aan_lokaal_model(invoer)
                if lokaal_antwoord:
                    extra_antwoord = lokaal_antwoord
        taken = functies.project["taken"]
        notities = functies.project["notities"]

        # De naam, taken en notities worden direct op schijf bewaard.
        if extra_antwoord is not None:
            print("AI: " + extra_antwoord)
        elif als_weerplaats:
            dag = wacht_op_weerplaats
            wacht_op_weerplaats = None
            if bericht == "annuleer":
                print("AI: Weervraag geannuleerd.")
            else:
                extra_antwoord = weerbericht(invoer, dag)
                if extra_antwoord.endswith("Bron: Open-Meteo."):
                    gegevens["weerplaats"] = invoer.strip()
                    bewaar_gegevens(gegevens)
                print("AI: " + extra_antwoord)
        elif weervraag is not None:
            dag, plaats = weervraag
            plaats = plaats or gegevens["weerplaats"]
            if plaats:
                extra_antwoord = weerbericht(plaats, dag)
                if extra_antwoord.endswith("Bron: Open-Meteo.") and weervraag[1]:
                    gegevens["weerplaats"] = plaats
                    bewaar_gegevens(gegevens)
            else:
                wacht_op_weerplaats = dag
                extra_antwoord = "Voor welke plaats? Typ bijvoorbeeld: Utrecht."
            print("AI: " + extra_antwoord)
        elif bericht.startswith("ik heet "):
            gegevens["naam"] = invoer[len("ik heet "):].strip().rstrip("!?., ").title()
            bewaar_gegevens(gegevens)
            extra_antwoord = f"Leuk je te ontmoeten, {gegevens['naam']}!"
            print("AI: " + extra_antwoord)
        elif bericht.startswith("taak:"):
            taak = invoer.split(":", 1)[1].strip()
            if taak:
                taken.append({"tekst": taak, "klaar": False})
                bewaar_gegevens(gegevens)
                print(f"AI: Taak toegevoegd: {taak}")
            else:
                print("AI: Typ iets achter 'taak:', bijvoorbeeld: taak: melk kopen")
        elif bericht == "taken":
            if not taken:
                print("AI: Je hebt nog geen taken.")
            for nummer, taak in enumerate(taken, 1):
                status = "klaar" if taak["klaar"] else "open"
                print(f"  {nummer}. [{status}] {taak['tekst']}")
        elif bericht.startswith("klaar:") or bericht.startswith("verwijder taak:"):
            nummer = invoer.split(":", 1)[1].strip()
            if not nummer.isdigit() or not 1 <= int(nummer) <= len(taken):
                print("AI: Gebruik een taaknummer uit de lijst 'taken'.")
            elif bericht.startswith("klaar:"):
                taken[int(nummer) - 1]["klaar"] = True
                bewaar_gegevens(gegevens)
                print(f"AI: Taak {nummer} is klaar.")
            else:
                verwijderde_taak = taken.pop(int(nummer) - 1)
                bewaar_gegevens(gegevens)
                print(f"AI: Taak verwijderd: {verwijderde_taak['tekst']}")
        elif bericht.startswith("notitie:"):
            inhoud = invoer.split(":", 1)[1].strip()
            if inhoud:
                notities.append({"titel": inhoud.splitlines()[0][:60], "inhoud": inhoud})
                bewaar_gegevens(gegevens)
                print("AI: Notitie bewaard.")
            else:
                print("AI: Typ iets achter 'notitie:', bijvoorbeeld: notitie: een idee")
        elif bericht in {"notities", "toon mijn notities", "toon notities"}:
            if not notities:
                print("AI: Je hebt nog geen notities.")
            for nummer, notitie in enumerate(notities, 1):
                print(f"  {nummer}. {notitie['titel']}: {notitie['inhoud']}")
        elif bericht.startswith("hernoem notitie:") or bericht.startswith("wijzig notitie:") or bericht.startswith("verwijder notitie:"):
            opdracht, waarde = invoer.split(":", 1)
            delen = [deel.strip() for deel in waarde.split("|", 1)]
            nummer = delen[0]
            if not nummer.isdigit() or not 1 <= int(nummer) <= len(notities):
                print("AI: Gebruik een notitienummer uit de lijst 'toon mijn notities'.")
            elif bericht.startswith("verwijder notitie:"):
                verwijderde_notitie = notities.pop(int(nummer) - 1)
                bewaar_gegevens(gegevens)
                print(f"AI: Notitie verwijderd: {verwijderde_notitie['titel']}")
            elif len(delen) < 2 or not delen[1]:
                print("AI: Gebruik bijvoorbeeld: hernoem notitie: 1 | Nieuwe titel")
            elif bericht.startswith("hernoem notitie:"):
                notities[int(nummer) - 1]["titel"] = delen[1][:60]
                bewaar_gegevens(gegevens)
                print("AI: Notitie hernoemd.")
            else:
                notities[int(nummer) - 1]["inhoud"] = delen[1][:4000]
                bewaar_gegevens(gegevens)
                print("AI: Notitie aangepast.")
        elif bericht.startswith("reken "):
            try:
                uitkomst = bereken(invoer[6:].strip())
                print(f"AI: {uitkomst:g}")
            except ValueError as fout:
                print(f"AI: {fout}")
        elif bedoeling == "hulp":
            toon_hulp()
        elif bedoeling == "begroeting":
            naam = gegevens["naam"]
            if naam:
                extra_antwoord = f"Hoi {naam}! Leuk dat je er bent."
            else:
                extra_antwoord = random.choice([
                    "Hallo! Leuk dat je er bent.",
                    "Hoi! Hoe kan ik je helpen?",
                    "Hey! Fijn dat je er bent.",
                ])
            print("AI: " + extra_antwoord)
        elif bedoeling == "jouw_naam":
            naam = gegevens["naam"]
            extra_antwoord = f"Jij heet {naam}." if naam else "Dat weet ik nog niet. Typ bijvoorbeeld: ik heet Mika"
            print("AI: " + extra_antwoord)
        elif bedoeling == "hoe_gaat_het":
            extra_antwoord = "Met mij gaat het goed!"
            print("AI: " + extra_antwoord)
        elif bedoeling == "naam_chatbot":
            extra_antwoord = "Ik ben MikaGPT."
            print("AI: " + extra_antwoord)
        elif bedoeling == "bedankt":
            extra_antwoord = "Graag gedaan!"
            print("AI: " + extra_antwoord)
        elif bedoeling == "mogelijkheden":
            if gegevens["antwoordstijl"] == "kort":
                extra_antwoord = "Ik kan taken, notities, geheugen, projecten en rekenen. Typ help."
            else:
                extra_antwoord = "Ik kan taken en notities bewaren, rekenen, voorkeuren onthouden, projecten en doelen beheren en een paar bekende vragen beantwoorden. Typ help voor voorbeelden."
            print("AI: " + extra_antwoord)
        elif bedoeling == "tijd":
            extra_antwoord = "Het is " + datetime.now().strftime("%H:%M") + "."
            print("AI: " + extra_antwoord)
        elif bedoeling == "datum":
            extra_antwoord = "Vandaag is " + datetime.now().strftime("%d-%m-%Y") + "."
            print("AI: " + extra_antwoord)
        elif bedoeling == "afsluiten":
            # Een afscheid is gewoon een bericht. Het gesprek blijft bewaard,
            # zodat de gebruiker later op hetzelfde onderwerp kan doorgaan.
            extra_antwoord = "Tot ziens!"
            print("AI: " + extra_antwoord)
        else:
            gesprek = functies.project["gesprek"]
            vorige_vraag = gesprek[-1]["vraag"] if gesprek else ""
            extra_antwoord = vraag_aan_lokaal_model(invoer)
            if extra_antwoord is None:
                extra_antwoord = antwoord_op_onbekend(invoer, vorige_vraag, gegevens["antwoordstijl"])
            print("AI: " + extra_antwoord)

        try:
            functies.onthoud_gesprek(invoer, extra_antwoord or "")
        except OSError:
            print("AI: Ik kon dit gesprek niet bewaren.")

    functies.sluit_browser()
    print("AI: Tot ziens!")


if __name__ == "__main__":
    main()
