"""Vraag het lokale Ollama-model om hulp bij vrije Nederlandse zinnen."""

import json
import os
import re
import subprocess
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, Request, build_opener


LOKAAL_ADRES = "http://127.0.0.1:11434/api/chat"
MODEL = "mikagpt-local"
LOKALE_VERBINDING = build_opener(ProxyHandler({}))

# Korte algemene woorden zeggen weinig over het onderwerp van een gesprek.
STOPWOORDEN = {
    "ik", "je", "jij", "mijn", "het", "de", "een", "en", "of", "dat", "dit",
    "die", "wat", "hoe", "waar", "wie", "welke", "is", "zijn", "kan", "kun",
    "wil", "zou", "moet", "met", "voor", "over", "van", "naar", "ook", "nog",
    "dan", "er", "me", "mij", "we", "wij", "ze", "zij", "ja", "nee", "ok",
}
OPDRACHTEN = (
    "website ", "frans leer:", "frans vergeet:", "leren f-n:", "leren n-f:",
    "overhoren f-n:", "overhoren n-f:", "maak bestand:", "vervang tekst:",
    "voer code uit:", "test code:", "test uitvoer:", "controleer code:",
    "project ", "taak:", "notitie:", "klaar:", "afspraak:", "herinnering:",
    "antwoord ",
)


def gesprekswoorden(tekst):
    return set(re.findall(r"[^\W\d_]{3,}", tekst.casefold(), re.UNICODE)) - STOPWOORDEN


def kies_gesprekscontext(gesprek, vraag):
    """Neem het recente gesprek mee en haal oudere berichten over hetzelfde onderwerp op."""
    bruikbaar = [item for item in gesprek if item.get("vraag") and item.get("antwoord")
                and not item["vraag"].casefold().startswith(OPDRACHTEN)]
    recent = bruikbaar[-5:]
    zoekwoorden = gesprekswoorden(vraag)
    ouder = bruikbaar[:-5]
    treffers = []
    if zoekwoorden:
        for index, item in enumerate(ouder):
            inhoud = item["vraag"] + " " + item["antwoord"]
            score = len(zoekwoorden & gesprekswoorden(inhoud))
            if score:
                treffers.append((score, index, item))
    relevant = [item for _, _, item in sorted(treffers, key=lambda t: (t[0], t[1]), reverse=True)[:3]]
    gekozen = relevant + recent
    return [item for item in bruikbaar if any(item is kandidaat for kandidaat in gekozen)]


def zorg_dat_ollama_draait():
    """Start de reeds geïnstalleerde lokale server als die nog niet draait."""
    statusadres = "http://127.0.0.1:11434/api/version"
    try:
        with LOKALE_VERBINDING.open(statusadres, timeout=1):
            return True
    except (URLError, TimeoutError, OSError):
        pass
    if os.name != "nt":
        return False
    programma = Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Ollama" / "ollama.exe"
    if not programma.is_file():
        return False
    try:
        subprocess.Popen(
            [str(programma), "serve"], cwd=programma.parent,
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
    except OSError:
        return False
    for _ in range(10):
        time.sleep(0.5)
        try:
            with LOKALE_VERBINDING.open(statusadres, timeout=1):
                return True
        except (URLError, TimeoutError, OSError):
            continue
    return False


def antwoord_van_model(vraag, gesprek, naam=None, antwoordstijl="normaal",
                      voorkeuren=None, projectnaam=None):
    """Gebruik alleen het model op deze computer; geef None bij een storing."""
    if not zorg_dat_ollama_draait():
        return None
    if antwoordstijl == "kort":
        stijl = "antwoord in één of twee duidelijke zinnen"
        maximum_tokens = 120
    elif antwoordstijl == "uitgebreid":
        stijl = "geef waar nuttig een grondige uitleg van ongeveer 250 tot 400 woorden, in korte alinea's"
        maximum_tokens = 650
    else:
        stijl = "geef bij een inhoudelijke vraag een duidelijke uitleg van ongeveer 150 tot 250 woorden, in korte alinea's"
        maximum_tokens = 420
    instructie = (
        "Je bent MikaGPT, een lokale Nederlandse assistent. "
        f"Antwoord in het Nederlands: {stijl}. "
        "Geef bij een langere uitleg duidelijke kopjes in hoofdletters: KORTE UITLEG, "
        "VOORBEELD (alleen wanneer een betrouwbaar voorbeeld helpt), STAPPENPLAN "
        "(alleen bij een vraag over hoe iets moet) en SAMENVATTING. "
        "Beantwoord eerst de vraag, leg daarna de belangrijkste redenen uit "
        "en geef een concreet voorbeeld als dat helpt. Gebruik gewone tekst met lege regels; "
        "bij stappen gebruik je een genummerde lijst. "
        "Een simpele begroeting of korte bevestiging hoeft niet lang te zijn. "
        "Gebruik eerdere berichten voor verwijzingen zoals 'dat', 'die', 'ja' en 'nee'. "
        "Als de gebruiker kort antwoordt op jouw vorige vraag, reageer dan op die vraag. "
        "Als de gebruiker instemt met iets dat je net aanbood, geef dat dan meteen; "
        "stel dezelfde vraag niet opnieuw. "
        "Vraag alleen om uitleg als de betekenis echt onduidelijk is. "
        "Eerdere antwoorden kunnen fout zijn; gebruik ze niet als bewijs voor feiten. "
        "Controleer voor je antwoord of iedere feitelijke bewering logisch en bekend is. "
        "Noem geen specifieke historische gebeurtenissen, plaatsen, cijfers of voorbeelden "
        "als je daarvan niet zeker bent. Verzin niets om een antwoord langer te maken. "
        "Als je de feiten niet betrouwbaar weet, zeg dat eerlijk en leg alleen uit wat je wel weet. "
        "Zeg eerlijk wanneer je iets niet weet. "
        "Doe niet alsof je taken, bestanden of instellingen hebt veranderd; "
        "die acties worden door andere delen van MikaGPT uitgevoerd."
    )
    if naam:
        instructie += f" De gebruiker heet {naam}."
    if projectnaam:
        instructie += f" Het actieve project heet {projectnaam}."
    berichten = [{"role": "system", "content": instructie}]
    if voorkeuren:
        berichten.append({"role": "system", "content":
                         "Door de gebruiker opgeslagen voorkeuren (geen bewijs voor feiten): "
                         + "; ".join(voorkeuren[-5:])[:500]})
    for item in kies_gesprekscontext(gesprek, vraag):
        berichten.append({"role": "user", "content": item["vraag"]})
        berichten.append({"role": "assistant", "content": item["antwoord"]})
    berichten.append({"role": "user", "content": vraag})
    inhoud = json.dumps({
        "model": MODEL,
        "messages": berichten,
        "stream": False,
        "think": False,
        "options": {"num_predict": maximum_tokens, "temperature": 0.3,
                    "repeat_penalty": 1.1, "num_ctx": 4096},
    }, ensure_ascii=False).encode("utf-8")
    verzoek = Request(LOKAAL_ADRES, data=inhoud, headers={"Content-Type": "application/json"})
    try:
        with LOKALE_VERBINDING.open(verzoek, timeout=110) as reactie:
            antwoord = json.load(reactie)["message"]["content"]
    except (HTTPError, URLError, TimeoutError, OSError, KeyError, ValueError, TypeError):
        return None
    antwoord = re.sub(r"<think>.*?</think>", "", antwoord, flags=re.DOTALL).strip()
    return antwoord or None
