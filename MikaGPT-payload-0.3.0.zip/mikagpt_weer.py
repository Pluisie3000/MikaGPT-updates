"""Actuele weersverwachtingen via Open-Meteo, zonder extra installatie."""

import json
import re
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


WEERTEKST = {
    0: "helder", 1: "meestal helder", 2: "half bewolkt", 3: "bewolkt",
    45: "mistig", 48: "mistig", 51: "lichte motregen", 53: "motregen",
    55: "sterke motregen", 56: "ijzel", 57: "ijzel", 61: "lichte regen",
    63: "regen", 65: "zware regen", 66: "ijzel", 67: "ijzel",
    71: "lichte sneeuw", 73: "sneeuw", 75: "zware sneeuw", 77: "sneeuwkorrels",
    80: "lichte buien", 81: "buien", 82: "zware buien",
    85: "lichte sneeuwbuien", 86: "zware sneeuwbuien",
    95: "onweer", 96: "onweer met hagel", 99: "onweer met hagel",
}
BRON = "Bron: https://open-meteo.com/"


def herken_weervraag(invoer):
    """Geef (dag, plaats) voor een gewone Nederlandse weervraag, anders None.

    Plaatsnamen mogen meerdere woorden bevatten, bijvoorbeeld 'Den Helder'.
    """
    tekst = invoer.strip().lower().rstrip("!?., ")
    tekst = re.sub(r"\bhte\b", "het", tekst)
    tekst = re.sub(r"\bword\b", "wordt", tekst)
    if "weer" not in tekst:
        return None
    # Alleen vragen die duidelijk om een weersverwachting gaan behandelen we hier.
    if not re.search(r"\b(wat|hoe|weer|verwachting)\b", tekst):
        return None
    dag = 1 if re.search(r"\bmorgen\b", tekst) else 0
    plaats_match = re.search(r"\bin\s+(.+)$", tekst)
    plaats = plaats_match.group(1).strip() if plaats_match else None
    if plaats and plaats in {"de", "het", "een"}:
        plaats = None
    # 'weer morgen Alkmaar' is ook een begrijpelijke korte vraag.
    if not plaats:
        kort = re.fullmatch(r"weer\s+(?:vandaag|morgen)\s+(.+)", tekst)
        if kort:
            plaats = kort.group(1).strip()
    return dag, plaats


def _haal_json_op(adres, parameters):
    url = adres + "?" + urlencode(parameters)
    verzoek = Request(url, headers={"User-Agent": "MikaGPT/0.2 (weerfunctie)"})
    with urlopen(verzoek, timeout=10) as antwoord:
        return json.load(antwoord)


def _waarde(reeks, dag, standaard=None):
    """Lees veilig een dagwaarde uit een antwoord van de weerdienst."""
    return reeks[dag] if isinstance(reeks, list) and len(reeks) > dag else standaard


def weerbericht(plaats, dag=0):
    """Zoek een plaats en geef de actuele verwachting voor vandaag of morgen."""
    plaats = plaats.strip().rstrip("!?., ")
    if len(plaats) < 2 or len(plaats) > 100:
        return "Voor welke plaats wil je het weer weten? Typ bijvoorbeeld: Utrecht."
    try:
        locaties = _haal_json_op(
            "https://geocoding-api.open-meteo.com/v1/search",
            {"name": plaats, "count": 5, "language": "nl", "format": "json"},
        ).get("results", [])
        if not locaties:
            return f"Ik kan de plaats '{plaats}' niet vinden. Probeer bijvoorbeeld 'Utrecht, Nederland'."
        # Een Nederlandse, exacte plaatsnaam krijgt voorrang.
        exacte = [locatie for locatie in locaties if locatie.get("name", "").casefold() == plaats.casefold()]
        keuze = next((locatie for locatie in exacte if locatie.get("country_code") == "NL"), None)
        locatie = keuze or (exacte[0] if exacte else locaties[0])
        verwachting = _haal_json_op(
            "https://api.open-meteo.com/v1/forecast",
            {
                "latitude": locatie["latitude"], "longitude": locatie["longitude"],
                "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,wind_speed_10m_max",
                "timezone": "auto", "forecast_days": 2,
            },
        )["daily"]
        code = _waarde(verwachting.get("weather_code"), dag)
        minimum = _waarde(verwachting.get("temperature_2m_min"), dag)
        maximum = _waarde(verwachting.get("temperature_2m_max"), dag)
        kans = _waarde(verwachting.get("precipitation_probability_max"), dag)
        neerslag = _waarde(verwachting.get("precipitation_sum"), dag)
        wind = _waarde(verwachting.get("wind_speed_10m_max"), dag)
        if code is None or minimum is None or maximum is None:
            raise ValueError("Onvolledige weersverwachting")
    except (HTTPError, URLError, TimeoutError, OSError, ValueError, KeyError, IndexError, TypeError):
        return "Ik kan het weer nu niet ophalen. Controleer je internetverbinding en probeer het later opnieuw."

    tijd = "Morgen" if dag else "Vandaag"
    naam = locatie["name"]
    land = locatie.get("country", "")
    gebied = f"{naam}, {land}" if land else naam
    beschrijving = WEERTEKST.get(code, "wisselend weer")
    temperatuur = f"Temperatuur: {round(minimum)} tot {round(maximum)} °C."
    regen = "Regen: "
    if kans is not None:
        regen += f"{round(kans)}% kans"
    else:
        regen += "geen regenkans bekend"
    if neerslag is not None:
        regen += f", ongeveer {neerslag:.1f} mm neerslag."
    else:
        regen += "."
    wind_tekst = f"Wind: maximaal {round(wind)} km/u." if wind is not None else "Wind: geen windsnelheid bekend."
    return f"{tijd} in {gebied} wordt het {beschrijving}.\n\n{temperatuur}\n{regen}\n{wind_tekst}\n\n{BRON}"
