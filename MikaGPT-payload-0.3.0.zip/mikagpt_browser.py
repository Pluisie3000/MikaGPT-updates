"""Lokale browser voor website-opdrachten; inloggen doet de gebruiker zelf."""

import re
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import urlopen


PROJECTMAP = Path(__file__).resolve().parent
DOEL_SCORE = 90


def vind_chrome():
    """Zoek de geïnstalleerde Chrome zonder iets te downloaden."""
    kandidaten = [shutil.which("chrome.exe")]
    for basis in (os.environ.get("PROGRAMFILES"), os.environ.get("PROGRAMFILES(X86)"),
                  os.environ.get("LOCALAPPDATA")):
        if basis:
            kandidaten.append(Path(basis) / "Google" / "Chrome" / "Application" / "chrome.exe")
    for kandidaat in kandidaten:
        if kandidaat and Path(kandidaat).is_file():
            return str(kandidaat)
    raise FileNotFoundError("Google Chrome is niet geïnstalleerd.")


def vrije_poort():
    with socket.socket() as verbinding:
        verbinding.bind(("127.0.0.1", 0))
        return verbinding.getsockname()[1]


def lees_scores(knoppen):
    """Lees zichtbare oefenknoppen, ook als er nog geen percentage staat."""
    resultaten = []
    for tekst in knoppen:
        regel = " ".join(tekst.split())
        match = re.fullmatch(r"(?:(\d{1,3}%|-)\s*)?((?:[A-H]|Ch1):\s*(?:Oefenen|Leren|Overhoren)(?:\s+.+)?)", regel)
        if match:
            score = None if not match.group(1) or match.group(1) == "-" else int(match.group(1)[:-1])
            if score is None or score <= 100:
                resultaten.append((match.group(2), score))
    return resultaten


class WebsiteWerk:
    """Houd een aparte Chrome-sessie open zonder wachtwoorden te bewaren."""

    def __init__(self):
        self.playwright = None
        self.browser = None
        self.context = None
        self.pagina = None
        self.chromium_proces = None
        self.profielmap = None
        self.poort = None

    def start(self, adres):
        try:
            onderdelen = urlsplit(adres)
            geldig = (onderdelen.scheme in {"http", "https"} and bool(onderdelen.hostname)
                      and onderdelen.username is None and onderdelen.password is None
                      and onderdelen.port != 0 and not any(teken.isspace() for teken in adres)
                      and "\\" not in adres)
        except ValueError:
            geldig = False
        if not geldig:
            return "Gebruik een volledig webadres dat met https:// of http:// begint."
        if self.context is not None:
            return "Er is al een website open. Typ 'website sluit' voordat je een andere opent."
        if str(PROJECTMAP / "browser_deps") not in sys.path:
            sys.path.insert(0, str(PROJECTMAP / "browser_deps"))
        try:
            from playwright.sync_api import sync_playwright

            bestaande_poort = os.environ.get("MIKAGPT_BROWSER_PORT")
            if bestaande_poort:
                self.poort = int(bestaande_poort)
                self.playwright = sync_playwright().start()
                self.browser = self.playwright.chromium.connect_over_cdp(
                    f"http://127.0.0.1:{self.poort}"
                )
                self.context = self.browser.contexts[0]
                self.pagina = next(
                    (pagina for pagina in self.context.pages
                     if urlsplit(pagina.url).hostname == urlsplit(adres).hostname), None
                )
                if self.pagina is None:
                    self.pagina = self.context.new_page()
                    self.pagina.goto(adres, wait_until="domcontentloaded", timeout=30000)
                return "Ik ben verbonden met het al geopende Chrome-venster. Typ 'website status'."

            chrome = vind_chrome()
            poort = vrije_poort()
            self.poort = poort
            self.profielmap = tempfile.TemporaryDirectory(prefix="mikagpt_chrome_", ignore_cleanup_errors=True)
            self.chromium_proces = subprocess.Popen(
                [chrome, "--no-first-run", "--no-default-browser-check",
                 "--remote-debugging-address=127.0.0.1",
                 f"--remote-debugging-port={poort}",
                 f"--user-data-dir={self.profielmap.name}", "about:blank"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            for _ in range(100):
                try:
                    with urlopen(f"http://127.0.0.1:{poort}/json/version", timeout=1):
                        break
                except OSError:
                    if self.chromium_proces.poll() is not None:
                        raise RuntimeError("Chrome stopte tijdens het openen.")
                    time.sleep(0.1)
            else:
                raise RuntimeError("Chrome kon niet worden verbonden.")
            self.playwright = sync_playwright().start()
            self.browser = self.playwright.chromium.connect_over_cdp(f"http://127.0.0.1:{poort}")
            self.context = self.browser.contexts[0]
            herkenning = self.context.new_page()
            herkenning.goto(
                "data:text/html;charset=utf-8,"
                "<title>MIKAGPT - DIT VENSTER</title>"
                "<body style='font:32px Arial;text-align:center;padding:8vh'>"
                "<h1>MIKAGPT - DIT VENSTER</h1>"
                "<p>Log in op het Noordhoff-tabblad naast dit tabblad.</p>"
                "</body>"
            )
            self.pagina = self.context.new_page()
            self.pagina.set_default_timeout(5000)
            self.pagina.goto(adres, wait_until="domcontentloaded", timeout=30000)
        except Exception:
            self.sluit()
            return "De website kon niet worden geopend. Controleer of Chrome werkt en probeer het opnieuw."
        return "Het Chrome-venster heeft een tabblad 'MIKAGPT - DIT VENSTER'. Log in op het Noordhoff-tabblad direct daarnaast. Typ daarna 'website status'. Je wachtwoord komt niet in de MikaGPT-chat."

    def status(self):
        if self.context is None:
            return "Er staat nog geen website open. Typ: website start: https://apps.noordhoff.nl/..."
        scores = []
        zichtbare_paginas = []
        # Een nieuwe CDP-verbinding ontdekt ook tabbladen die Entree buiten
        # Playwright heeft geopend nadat de oorspronkelijke verbinding startte.
        status_browser = None
        try:
            status_browser = self.playwright.chromium.connect_over_cdp(
                f"http://127.0.0.1:{self.poort}"
            )
            paginas = [pagina for context in status_browser.contexts for pagina in context.pages]
            for pagina in paginas:
                if pagina.is_closed():
                    continue
                try:
                    adres = urlsplit(pagina.url)
                    if adres.scheme == "data":
                        zichtbare_paginas.append("MIKAGPT - DIT VENSTER")
                        continue
                    if adres.hostname != "apps.noordhoff.nl":
                        zichtbare_paginas.append(adres.hostname or "onbekende pagina")
                        continue
                    knoppen = pagina.get_by_role("button").all_text_contents()
                    scores = lees_scores(knoppen)
                    if scores:
                        break
                    zichtbare_paginas.append(
                        f"Noordhoff ({adres.path.rsplit('/', 1)[-1] or 'startpagina'}, "
                        f"{len(knoppen)} knoppen)"
                    )
                except Exception:
                    zichtbare_paginas.append("pagina wordt geladen")
        except Exception:
            return "De verbinding met Chrome is verbroken. Open de website opnieuw."
        finally:
            if status_browser is not None:
                status_browser.close()
        if not scores:
            schermen = ", ".join(zichtbare_paginas[:3]) or "geen open tabbladen"
            return f"Ik zie nog geen oefenscores in mijn Chrome-venster. Open tabbladen: {schermen}."
        onder_doel = [(naam, score) for naam, score in scores if score is None or score <= DOEL_SCORE]
        if not onder_doel:
            return "Alle onderdelen met een zichtbare score staan boven 90%."
        regels = [f"{naam}: {score}%" if score is not None else f"{naam}: nog niet gestart"
                  for naam, score in onder_doel]
        return "Deze onderdelen staan nog niet boven 90% of zijn nog niet gestart:\n" + "\n".join(regels)

    def sluit(self):
        if self.context is not None:
            try:
                self.context.close()
            except Exception:
                pass
        if self.browser is not None:
            try:
                self.browser.close()
            except Exception:
                pass
        if self.playwright is not None:
            try:
                self.playwright.stop()
            except Exception:
                pass
        if self.chromium_proces is not None and self.chromium_proces.poll() is None:
            try:
                self.chromium_proces.terminate()
                self.chromium_proces.wait(timeout=5)
            except (OSError, subprocess.TimeoutExpired):
                self.chromium_proces.kill()
        if self.profielmap is not None:
            self.profielmap.cleanup()
        self.playwright = self.browser = self.context = self.pagina = None
        self.chromium_proces = self.profielmap = None
        self.poort = None
