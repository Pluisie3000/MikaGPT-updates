"""Uitbreidingen voor MikaGPT. Alles in dit bestand werkt lokaal."""

import ast
import difflib
import html
import importlib
import re
import subprocess
import sys
import wave
import webbrowser
from datetime import datetime, timedelta
from pathlib import Path, PureWindowsPath
from urllib.parse import quote_plus, urlsplit

import mikagpt_frans


MAX_BESTAND = 200_000
TEKSTBESTANDEN = {".txt", ".md", ".py", ".json", ".csv", ".svg"}


def bereid_gegevens_voor(gegevens):
    """Vul nieuwe onderdelen aan zonder oude taken of notities te verliezen."""
    if not isinstance(gegevens, dict):
        raise ValueError("Het gegevensbestand moet een JSON-object bevatten.")
    gegevens.setdefault("naam", None)
    gegevens.setdefault("taken", [])
    gegevens.setdefault("notities", [])
    gegevens.setdefault("voorkeuren", [])
    gegevens.setdefault("antwoordstijl", "normaal")
    gegevens.setdefault("weerplaats", None)
    gegevens.setdefault("woordenboek", {})
    gegevens.setdefault("franse_woorden", {"quelque chose": "iets"})
    if (not isinstance(gegevens["franse_woorden"], dict)
            or any(not isinstance(frans, str) or not isinstance(nederlands, str)
                   for frans, nederlands in gegevens["franse_woorden"].items())):
        raise ValueError("De Franse woordenlijst in het gegevensbestand is ongeldig.")
    if not isinstance(gegevens["woordenboek"], dict):
        raise ValueError("Het woordenboek in het gegevensbestand is ongeldig.")
    for woord, item in gegevens["woordenboek"].items():
        if (not isinstance(woord, str) or not isinstance(item, dict)
                or not isinstance(item.get("betekenis"), str)
                or not isinstance(item.get("eigenschappen"), dict)
                or any(not isinstance(naam, str) or not isinstance(waarde, str)
                       for naam, waarde in item["eigenschappen"].items())):
            raise ValueError("Een geleerd woord in het gegevensbestand is ongeldig.")
    gegevens.setdefault("afspraken", [])
    gegevens.setdefault("actief_project", "Algemeen")
    gegevens.setdefault("projecten", {})
    if not isinstance(gegevens["projecten"], dict):
        raise ValueError("De projecten in het gegevensbestand zijn ongeldig.")
    nieuw_algemeen = "Algemeen" not in gegevens["projecten"]
    gegevens["projecten"].setdefault("Algemeen", nieuw_project())
    algemeen = gegevens["projecten"]["Algemeen"]
    if not isinstance(algemeen, dict):
        raise ValueError("Het project Algemeen in het gegevensbestand is ongeldig.")
    if not isinstance(gegevens["taken"], list) or not isinstance(gegevens["notities"], list):
        raise ValueError("Oude taken of notities in het gegevensbestand zijn ongeldig.")
    # Oude versies bewaarden taken en notities direct bovenaan het JSON-bestand.
    if nieuw_algemeen:
        algemeen["taken"] = gegevens.get("taken", [])
        algemeen["notities"] = gegevens.get("notities", [])
    else:
        algemeen.setdefault("taken", gegevens.get("taken", []))
        algemeen.setdefault("notities", gegevens.get("notities", []))
    for project in gegevens["projecten"].values():
        if not isinstance(project, dict):
            raise ValueError("Een project in het gegevensbestand is ongeldig.")
        project.setdefault("doelen", [])
        project.setdefault("gesprek", [])
        project.setdefault("kennis", {})
        project.setdefault("taken", [])
        project.setdefault("notities", [])
        if not isinstance(project["taken"], list) or not isinstance(project["notities"], list):
            raise ValueError("Taken of notities in een project zijn ongeldig.")
        if not isinstance(project["doelen"], list) or not isinstance(project["gesprek"], list):
            raise ValueError("Doelen of gesprekken in een project zijn ongeldig.")
        if not isinstance(project["kennis"], dict):
            raise ValueError("Geleerde antwoorden in een project zijn ongeldig.")
        if any(not isinstance(item, dict) or not isinstance(item.get("tekst"), str) or not isinstance(item.get("klaar"), bool) for item in project["taken"]):
            raise ValueError("Een taak in het gegevensbestand is ongeldig.")
        # Oude versies bewaarden een notitie als alleen tekst. Zet die veilig om
        # naar een object met titel en inhoud, zodat notities hernoemd kunnen worden.
        vernieuwde_notities = []
        for item in project["notities"]:
            if isinstance(item, str):
                inhoud = item.strip()
                if not inhoud:
                    continue
                vernieuwde_notities.append({"titel": inhoud.splitlines()[0][:60], "inhoud": inhoud})
            elif (isinstance(item, dict) and isinstance(item.get("titel"), str)
                  and isinstance(item.get("inhoud"), str)
                  and item["titel"].strip() and item["inhoud"].strip()):
                vernieuwde_notities.append({"titel": item["titel"].strip()[:60],
                                           "inhoud": item["inhoud"].strip()[:4000]})
            else:
                raise ValueError("Een notitie in het gegevensbestand is ongeldig.")
        project["notities"] = vernieuwde_notities
        if any(not isinstance(item, dict) or not isinstance(item.get("vraag"), str) or not isinstance(item.get("antwoord"), str) for item in project["gesprek"]):
            raise ValueError("Een gespreksregel in het gegevensbestand is ongeldig.")
        if any(not isinstance(vraag, str) or not isinstance(antwoord, str) for vraag, antwoord in project["kennis"].items()):
            raise ValueError("Een geleerd antwoord in het gegevensbestand is ongeldig.")
        for doel in project["doelen"]:
            if not isinstance(doel, dict) or not isinstance(doel.get("tekst"), str) or not isinstance(doel.get("klaar"), bool) or not isinstance(doel.get("stappen"), list):
                raise ValueError("Een doel in het gegevensbestand is ongeldig.")
            if any(not isinstance(stap, dict) or not isinstance(stap.get("tekst"), str) or not isinstance(stap.get("klaar"), bool) for stap in doel["stappen"]):
                raise ValueError("Een stap in het gegevensbestand is ongeldig.")
    if not isinstance(gegevens["voorkeuren"], list) or not isinstance(gegevens["afspraken"], list):
        raise ValueError("Voorkeuren of afspraken in het gegevensbestand zijn ongeldig.")
    if any(not isinstance(item, str) for item in gegevens["voorkeuren"]):
        raise ValueError("Een voorkeur in het gegevensbestand is ongeldig.")
    for item in gegevens["afspraken"]:
        if not isinstance(item, dict) or not isinstance(item.get("tekst"), str) or item.get("soort") not in ("afspraak", "herinnering"):
            raise ValueError("Een afspraak in het gegevensbestand is ongeldig.")
        try:
            moment = datetime.fromisoformat(item["moment"])
            if moment.tzinfo is not None:
                raise ValueError("Tijdzones zijn hier niet ingesteld.")
        except (KeyError, TypeError, ValueError) as fout:
            raise ValueError("De datum van een afspraak is ongeldig.") from fout
    if not isinstance(gegevens["actief_project"], str):
        raise ValueError("Het actieve project in het gegevensbestand is ongeldig.")
    if gegevens["naam"] is not None and not isinstance(gegevens["naam"], str):
        raise ValueError("De naam in het gegevensbestand is ongeldig.")
    if gegevens["weerplaats"] is not None and not isinstance(gegevens["weerplaats"], str):
        raise ValueError("De bewaarde weerplaats is ongeldig.")
    if gegevens["antwoordstijl"] not in ("normaal", "kort", "uitgebreid"):
        raise ValueError("De antwoordstijl in het gegevensbestand is ongeldig.")
    if gegevens["actief_project"] not in gegevens["projecten"]:
        gegevens["actief_project"] = "Algemeen"
    return gegevens


def nieuw_project():
    return {"doelen": [], "gesprek": [], "kennis": {}, "taken": [], "notities": []}


class Functies:
    """Houd extra opdrachten, projectgegevens en bevestigingen bij."""

    def __init__(self, gegevens, bewaar, projectmap):
        self.gegevens = bereid_gegevens_voor(gegevens)
        self.bewaar = bewaar
        self.projectmap = Path(projectmap)
        self.wacht_op_bevestiging = None
        self.wacht_op_doel = False
        self.website_werk = None
        self.huiswerk_oefening = None
        self.actief_bestand = None
        # Nieuwe opdrachten kunnen later als extra gereedschap worden toegevoegd.
        self.gereedschap = [
            ("huiswerkmodus", self.huiswerk),
            ("Franse woorden oefenen", self.frans),
            ("geheugen", self.geheugen),
            ("projecten", self.projecten),
            ("doelen en plannen", self.doelen),
            ("agenda", self.agenda),
            ("website-scores bekijken", self.website),
            ("links openen", self.open_link),
            ("zoeken in je browser", self.zoek_internet),
            ("bestanden en media", self.bestanden),
            ("code controleren en uitvoeren", self.code),
            ("foutmeldingen uitleggen", self.fout_uitleg),
            ("posters maken", self.poster),
            ("afbeeldingen bewerken", self.afbeelding),
            ("rekenen", None),
        ]

    @property
    def project(self):
        return self.gegevens["projecten"][self.gegevens["actief_project"]]

    def registreer_gereedschap(self, naam, functie):
        """Voeg een lokale functie toe die (tekst, kleine_tekst) -> antwoord gebruikt."""
        if not naam or not callable(functie):
            raise ValueError("Geef een naam en een aanroepbare functie op.")
        self.gereedschap.append((naam, functie))

    def huiswerk(self, tekst, klein):
        """Help eerst met denken en controleer oefenantwoorden waar dat betrouwbaar kan."""
        if not klein.startswith("huiswerk "):
            return None
        if ":" not in tekst:
            return "Kies uitleg, voorbeeld, oefenvraag of controleer mijn antwoord."
        soort, onderwerp = tekst.split(":", 1)
        soort = soort.casefold().strip()
        onderwerp = onderwerp.strip()
        if soort == "huiswerk uitleg":
            if not onderwerp:
                return "Welk onderwerp wil je begrijpen?"
            return (f"HUISWERK UITLEG — {onderwerp}\n\n"
                    "1. Lees de vraag en onderstreep wat je moet uitzoeken.\n"
                    "2. Schrijf op wat je al weet.\n"
                    "3. Kies één kleine eerste stap.\n"
                    "4. Controleer of die stap logisch is voordat je verdergaat.\n\n"
                    f"Hint: leg eerst in je eigen woorden uit wat '{onderwerp}' betekent. "
                    "Daarna kan ik een voorbeeld of oefenvraag maken.")
        if soort == "huiswerk voorbeeld":
            if not onderwerp:
                return "Noem het onderwerp waarvoor je een voorbeeld wilt."
            return (f"VOORBEELD — {onderwerp}\n\n"
                    "Stap 1: bepaal wat de vraag precies vraagt.\n"
                    "Stap 2: kies de regel, formule of informatie die erbij hoort.\n"
                    "Stap 3: pas die rustig toe en schrijf iedere tussenstap op.\n"
                    "Stap 4: vergelijk je uitkomst met de oorspronkelijke vraag.\n\n"
                    "Probeer nu dezelfde aanpak op een eigen oefenvraag.")
        if soort == "huiswerk oefenvraag":
            if not onderwerp:
                return "Noem eerst een onderwerp, bijvoorbeeld: huiswerk oefenvraag: breuken"
            klein_onderwerp = onderwerp.casefold()
            if any(woord in klein_onderwerp for woord in ("rekenen", "wiskunde", "som", "breuk", "procent")):
                eerste = 12 + (len(onderwerp) % 7)
                tweede = 3 + (len(onderwerp) % 5)
                vraag = f"{eerste} × {tweede}"
                self.huiswerk_oefening = {"vraag": vraag, "antwoord": str(eerste * tweede), "onderwerp": onderwerp}
                return f"OEFENVRAAG — {onderwerp}\n\nBereken: {vraag}\n\nSchrijf eerst je tussenstappen op. Typ daarna: huiswerk controleer: jouw antwoord"
            if "frans" in klein_onderwerp and self.gegevens["franse_woorden"]:
                frans, nederlands = sorted(self.gegevens["franse_woorden"].items())[0]
                self.huiswerk_oefening = {"vraag": frans, "antwoord": mikagpt_frans.sleutel(nederlands), "onderwerp": onderwerp}
                return f"OEFENVRAAG — Frans\n\nWat betekent '{frans}' in het Nederlands?\n\nDenk eerst zelf na. Typ daarna: huiswerk controleer: jouw antwoord"
            self.huiswerk_oefening = {"vraag": onderwerp, "antwoord": None, "onderwerp": onderwerp}
            return (f"OEFENVRAAG — {onderwerp}\n\nLeg in 2 of 3 zinnen uit wat je al weet over dit onderwerp. "
                    "Gebruik minstens één belangrijk begrip.\n\nTyp daarna: huiswerk controleer: jouw antwoord")
        if soort == "huiswerk controleer":
            if not onderwerp:
                return "Typ je antwoord achter: huiswerk controleer:"
            oefening = self.huiswerk_oefening
            if not oefening:
                return "Maak eerst een oefenvraag met: huiswerk oefenvraag: onderwerp"
            verwacht = oefening.get("antwoord")
            antwoord = mikagpt_frans.sleutel(onderwerp)
            if verwacht is not None:
                if antwoord == verwacht:
                    return "Goed gedaan! Je antwoord klopt. Kijk nog één keer naar je tussenstappen, zodat je weet waarom het klopt."
                return ("Nog niet helemaal. Kijk opnieuw naar je tussenstappen en probeer het nog eens. "
                        "Hint: controleer welke bewerking of vertaling de vraag vraagt.")
            if len(onderwerp.split()) < 4:
                return "Je bent begonnen, maar leg iets meer uit: welk belangrijk begrip gebruik je en waarom?"
            return ("Je antwoord heeft een duidelijke poging. Controleer nu: beantwoord je de vraag, gebruik je een begrip uit het onderwerp, "
                    "en kun je uitleggen waarom jouw antwoord klopt? Vraag daarna om een voorbeeld als je vastloopt.")
        return None

    def frans(self, tekst, klein):
        """Gebruik één woordenlijst voor Frans-Nederlands en Nederlands-Frans."""
        return mikagpt_frans.opdracht(tekst, self.gegevens, self.bewaar)

    def onthoud_gesprek(self, vraag, antwoord=""):
        """Bewaar een korte geschiedenis per project voor vervolgvragen."""
        if vraag.lower().strip() in {"stop", "doei", "tot ziens", "wis gesprekken", "bevestig", "annuleer"}:
            return
        if vraag.lower().startswith(("correctie:", "leer:", "vergeet kennis:", "leer woord:", "leer eigenschap:", "vergeet woord:", "frans leer:", "frans vergeet:", "leren f-n:", "leren n-f:", "overhoren f-n:", "overhoren n-f:", "antwoord ")):
            return
        gesprek = self.project["gesprek"]
        gesprek.append({"vraag": vraag, "antwoord": antwoord})
        del gesprek[:-30]
        self.bewaar(self.gegevens)

    def opdracht(self, invoer):
        """Geef een antwoord op een extra opdracht, of None als die onbekend is."""
        tekst = invoer.strip()
        klein = tekst.lower()
        if klein == "bevestig":
            if self.wacht_op_bevestiging is None:
                return "Er staat niets klaar om te bevestigen."
            actie = self.wacht_op_bevestiging
            self.wacht_op_bevestiging = None
            try:
                return actie()
            except (OSError, ValueError, subprocess.TimeoutExpired) as fout:
                return f"De actie is niet gelukt: {fout}"
        if klein == "annuleer":
            self.wacht_op_bevestiging = None
            self.wacht_op_doel = False
            return "De actie is geannuleerd."
        # Een nieuwe opdracht vervangt een eerder voorstel, zodat 'bevestig'
        # nooit onverwacht een oude bestandsactie uitvoert.
        self.wacht_op_bevestiging = None
        huiswerk_antwoord = self.huiswerk(tekst, klein)
        if huiswerk_antwoord is not None:
            return huiswerk_antwoord
        # Notities zijn opdrachten en geen kennisvragen voor Wikipedia.
        notities = self.project["notities"]
        if klein.startswith("notitie:"):
            inhoud = tekst.split(":", 1)[1].strip()
            if not inhoud:
                return "Typ iets achter 'notitie:', bijvoorbeeld: notitie: een idee"
            notities.append({"titel": inhoud.splitlines()[0][:60], "inhoud": inhoud})
            self.bewaar(self.gegevens)
            return "Notitie bewaard."
        if klein in {"notities", "toon notities", "toon mijn notities"}:
            if not notities:
                return "Je hebt nog geen notities."
            return "Mijn notities in " + self.gegevens["actief_project"] + ":\n" + "\n".join(
                f"{nummer}. {notitie['titel']}: {notitie['inhoud']}" for nummer, notitie in enumerate(notities, 1)
            )
        if klein.startswith(("hernoem notitie:", "wijzig notitie:", "verwijder notitie:", "verplaats notitie:")):
            _, waarde = tekst.split(":", 1)
            delen = [deel.strip() for deel in waarde.split("|", 1)]
            nummer = delen[0]
            if not nummer.isdigit() or not 1 <= int(nummer) <= len(notities):
                return "Gebruik een notitienummer uit 'toon mijn notities'."
            index = int(nummer) - 1
            if klein.startswith("verwijder notitie:"):
                verwijderd = notities.pop(index)
                self.bewaar(self.gegevens)
                return f"Notitie verwijderd: {verwijderd['titel']}"
            if len(delen) < 2 or not delen[1]:
                return "Gebruik bijvoorbeeld: hernoem notitie: 1 | Nieuwe titel"
            if klein.startswith("hernoem notitie:"):
                notities[index]["titel"] = delen[1][:60]
                self.bewaar(self.gegevens)
                return "Notitie hernoemd."
            if klein.startswith("wijzig notitie:"):
                notities[index]["inhoud"] = delen[1][:4000]
                self.bewaar(self.gegevens)
                return "Notitie aangepast."
            doel = next((naam for naam in self.gegevens["projecten"] if naam.casefold() == delen[1].casefold()), None)
            if not doel:
                return "Ik kan dat project niet vinden. Typ eerst 'projecten' om de namen te zien."
            self.gegevens["projecten"][doel]["notities"].append(notities.pop(index))
            self.bewaar(self.gegevens)
            return f"Notitie verplaatst naar {doel}."
        if self.wacht_op_doel:
            # Een andere duidelijke opdracht blijft een opdracht en wordt geen doel.
            opdracht_prefixen = ("taak:", "notitie:", "onthoud:", "project ", "afspraak:", "herinnering:", "reken ", "leer woord:", "leer eigenschap:", "open ", "ga naar ", "website ", "frans ", "leren ", "overhoren ")
            if klein in {"help", "hulp", "tools", "gereedschap", "taken", "notities", "geheugen", "projecten", "agenda"} or klein.startswith(opdracht_prefixen):
                self.wacht_op_doel = False
            else:
                self.wacht_op_doel = False
                return self.doelen("doel: " + tekst, "doel: " + klein)
        if klein in {"doelmodus", "wat wil je bereiken"}:
            self.wacht_op_doel = True
            return "Wat wil je bereiken? Typ je doel als volgend bericht, of typ 'annuleer'."
        if klein in {"tools", "gereedschap"}:
            return "Mijn gereedschap: " + ", ".join(naam for naam, _ in self.gereedschap) + "."

        for _, functie in self.gereedschap:
            if functie is None:
                continue
            antwoord = functie(tekst, klein)
            if antwoord is not None:
                return antwoord

        if klein in {"wat zei ik net", "wat zei ik hiervoor"}:
            gesprek = self.project["gesprek"]
            return f"Je zei: {gesprek[-1]['vraag']}" if gesprek else "Dit is je eerste bericht in dit project."
        if klein in {"wat zei jij net", "wat zei je net"}:
            antwoorden = [item["antwoord"] for item in self.project["gesprek"] if item["antwoord"]]
            return f"Ik zei: {antwoorden[-1]}" if antwoorden else "Ik heb nog geen eerder antwoord bewaard."
        if klein in {"waar hadden we het over", "wat hebben we besproken"}:
            berichten = [item["vraag"] for item in self.project["gesprek"]
                        if item["vraag"].casefold().strip("!?., ") not in
                        {"ok", "oke", "oké", "ja", "nee", "wat zei ik net", "wat zei jij net", "wat zei je net",
                         "waar hadden we het over", "wat hebben we besproken"}]
            if not berichten:
                return "We hebben nog geen onderwerp besproken."
            return "Je laatste berichten waren: " + " | ".join(berichten[-3:])
        if klein == "gesprek":
            gesprek = self.project["gesprek"][-10:]
            return "\n".join(f"{n}. {item['vraag']}" for n, item in enumerate(gesprek, 1)) or "Nog geen gesprek in dit project."
        if klein in {"en morgen", "en morgen?"}:
            gesprek = self.project["gesprek"]
            if gesprek and gesprek[-1]["vraag"].lower().strip("!?., ") == "welke datum is het":
                return "Morgen is " + (datetime.now() + timedelta(days=1)).strftime("%d-%m-%Y") + "."
            return "Waarover wil je iets weten voor morgen?"
        if klein == "wis gesprekken":
            self.project["gesprek"].clear()
            self.bewaar(self.gegevens)
            return "De opgeslagen gesprekken van dit project zijn gewist."
        if klein.startswith("leer: "):
            delen = tekst[6:].split("|", 1)
            if len(delen) != 2 or not all(deel.strip() for deel in delen):
                return "Gebruik: leer: vraag | antwoord"
            vraag, antwoord = (deel.strip() for deel in delen)
            self.project["kennis"][vraag.lower()] = antwoord
            self.bewaar(self.gegevens)
            return f"Ik heb geleerd hoe ik op '{vraag}' antwoord."
        if klein.startswith("correctie: "):
            gesprek = self.project["gesprek"]
            if not gesprek:
                return "Ik heb nog geen eerdere vraag om te corrigeren. Gebruik anders: leer: vraag | antwoord"
            laatste = gesprek[-1]["vraag"].lower().strip("!?., ")
            antwoord = tekst[11:].strip()
            if not antwoord:
                return "Typ na 'correctie:' het juiste antwoord."
            self.project["kennis"][laatste] = antwoord
            self.bewaar(self.gegevens)
            return "Bedankt, ik gebruik je correctie voortaan voor die vraag."
        if klein.startswith("vergeet kennis: "):
            vraag = klein[16:].strip()
            if self.project["kennis"].pop(vraag, None) is None:
                return "Die geleerde vraag ken ik niet."
            self.bewaar(self.gegevens)
            return "Dat geleerde antwoord is verwijderd."
        if klein in {"vertel een grap", "maak een grap"}:
            return "Waarom ging de computer naar de dokter? Hij had een virus."

        # Geleerde antwoorden worden voor vaste standaardzinnen gebruikt.
        kennis = self.project["kennis"]
        vraag = klein.strip("!?., ")
        if vraag in kennis:
            return kennis[vraag]
        bijna = difflib.get_close_matches(vraag, kennis, n=1, cutoff=0.85)
        if bijna:
            return kennis[bijna[0]]
        return None

    def geheugen(self, tekst, klein):
        if klein.startswith("onthoud: "):
            feit = tekst[9:].strip()
            if not feit:
                return "Typ iets na 'onthoud:'."
            self.gegevens["voorkeuren"].append(feit)
            self.bewaar(self.gegevens)
            return "Ik heb dat onthouden."
        if klein in {"geheugen", "wat weet je over mij"}:
            feiten = self.gegevens["voorkeuren"]
            if not feiten:
                return "Ik heb nog geen voorkeuren onthouden."
            return "Wat ik onthoud:\n" + "\n".join(f"{n}. {feit}" for n, feit in enumerate(feiten, 1))
        if klein.startswith("vergeet: "):
            keuze = tekst[9:].strip()
            feiten = self.gegevens["voorkeuren"]
            index = int(keuze) - 1 if keuze.isdigit() else next(
                (n for n, feit in enumerate(feiten) if feit.lower() == keuze.lower()), -1
            )
            if not 0 <= index < len(feiten):
                return "Gebruik een nummer uit 'geheugen' of typ de exacte tekst."
            verwijderd = feiten.pop(index)
            self.bewaar(self.gegevens)
            return f"Vergeten: {verwijderd}"
        if klein == "wis geheugen":
            self.gegevens["voorkeuren"].clear()
            self.bewaar(self.gegevens)
            return "Alle opgeslagen voorkeuren zijn gewist."
        if klein in {"antwoord kort", "antwoord uitgebreid", "antwoord normaal"}:
            stijl = klein.split()[1]
            self.gegevens["antwoordstijl"] = stijl
            self.bewaar(self.gegevens)
            return f"Ik gebruik nu de antwoordstijl '{stijl}' waar dat kan."
        return None

    def projecten(self, tekst, klein):
        if klein == "projecten":
            actief = self.gegevens["actief_project"]
            return "Projecten:\n" + "\n".join(
                f"{'*' if naam == actief else ' '} {naam}" for naam in self.gegevens["projecten"]
            )
        if klein in {"project", "project info"}:
            naam = self.gegevens["actief_project"]
            return (
                f"Actief project: {naam}. Taken: {len(self.project['taken'])}. "
                f"Notities: {len(self.project['notities'])}. Doelen: {len(self.project['doelen'])}. "
                f"Gespreksregels: {len(self.project['gesprek'])}."
            )
        if klein.startswith("project nieuw: "):
            naam = tekst[14:].strip()
            if not re.fullmatch(r"[\w -]{1,40}", naam, re.UNICODE):
                return "Gebruik een projectnaam van maximaal 40 letters, cijfers, spaties, _ of -."
            mapnaam = re.sub(r"[^\w-]", "_", naam, flags=re.UNICODE).casefold()
            if PureWindowsPath(mapnaam).is_reserved():
                return "Deze projectnaam is in Windows gereserveerd. Kies een andere naam."
            for bestaande_naam in self.gegevens["projecten"]:
                bestaande_map = re.sub(r"[^\w-]", "_", bestaande_naam, flags=re.UNICODE).casefold()
                if bestaande_map == mapnaam:
                    return "Deze projectnaam zou dezelfde bestandsmap gebruiken als een bestaand project. Kies een andere naam."
            self.gegevens["projecten"][naam] = nieuw_project()
            self.gegevens["actief_project"] = naam
            self.bewaar(self.gegevens)
            return f"Project '{naam}' gemaakt en gekozen."
        if klein.startswith("project gebruik: "):
            naam = tekst[16:].strip()
            gevonden = next((n for n in self.gegevens["projecten"] if n.lower() == naam.lower()), None)
            if gevonden is None:
                return "Dat project bestaat niet. Typ 'projecten' om ze te zien."
            self.gegevens["actief_project"] = gevonden
            self.bewaar(self.gegevens)
            return f"Actief project: {gevonden}."
        return None

    def doelen(self, tekst, klein):
        if klein.startswith("doel: "):
            doel = tekst[6:].strip()
            if not doel:
                return "Typ iets na 'doel:'."
            stappen = self.maak_plan(doel)
            self.project["doelen"].append({"tekst": doel, "stappen": stappen, "klaar": False})
            self.bewaar(self.gegevens)
            return f"Doel toegevoegd: {doel}\n" + "\n".join(f"{n}. {stap['tekst']}" for n, stap in enumerate(stappen, 1))
        if klein == "doelen":
            return "\n".join(
                f"{n}. [{'klaar' if doel['klaar'] else 'open'}] {doel['tekst']}"
                for n, doel in enumerate(self.project["doelen"], 1)
            ) or "Dit project heeft nog geen doelen."
        if klein.startswith("verwijder doel: "):
            nummer = klein.split(":", 1)[1].strip()
            doelen = self.project["doelen"]
            if not nummer.isdigit() or not 1 <= int(nummer) <= len(doelen):
                return "Gebruik een nummer uit 'doelen'."
            verwijderd = doelen.pop(int(nummer) - 1)
            self.bewaar(self.gegevens)
            return f"Doel verwijderd: {verwijderd['tekst']}"
        if klein.startswith("plan") and (klein == "plan" or klein[4:].strip().isdigit()):
            doelen = self.project["doelen"]
            keuze = klein[4:].strip()
            index = int(keuze) - 1 if keuze else len(doelen) - 1
            if not 0 <= index < len(doelen):
                return "Gebruik een doelnummer uit 'doelen'."
            doel = doelen[index]
            return f"Plan voor {doel['tekst']}:\n" + "\n".join(
                f"{n}. [{'klaar' if stap['klaar'] else 'open'}] {stap['tekst']}"
                for n, stap in enumerate(doel["stappen"], 1)
            )
        if klein.startswith("stap klaar: "):
            nummer = klein[11:].strip()
            doelen = self.project["doelen"]
            if not doelen or not nummer.isdigit() or not 1 <= int(nummer) <= len(doelen[-1]["stappen"]):
                return "Gebruik een stapnummer uit het laatste 'plan'."
            doelen[-1]["stappen"][int(nummer) - 1]["klaar"] = True
            doelen[-1]["klaar"] = all(stap["klaar"] for stap in doelen[-1]["stappen"])
            self.bewaar(self.gegevens)
            return f"Stap {nummer} is klaar."
        return None

    @staticmethod
    def maak_plan(doel):
        klein = doel.lower()
        if "presentatie" in klein:
            teksten = ["Bepaal onderwerp en publiek", "Maak een dia-indeling", "Schrijf de inhoud", "Controleer feiten en oefen"]
        elif "website" in klein:
            teksten = ["Beschrijf de pagina's", "Maak een eenvoudige versie", "Test de knoppen en teksten", "Verbeter het ontwerp"]
        elif any(woord in klein for woord in ("code", "programma", "script")):
            teksten = ["Beschrijf het gewenste gedrag", "Schrijf een kleine eerste versie", "Test voorbeelden", "Los fouten op en test opnieuw"]
        else:
            teksten = ["Beschrijf het eindresultaat", "Maak een eerste versie", "Controleer wat nog ontbreekt", "Rond af"]
        return [{"tekst": stap, "klaar": False} for stap in teksten]

    def agenda(self, tekst, klein):
        # Gewone spreektaal, bijvoorbeeld: "herinner me morgen om 18:00 aan mijn huiswerk".
        natuurlijk = re.fullmatch(
            r"herinner (?:me|mij)\s+(vandaag|morgen|overmorgen)\s+om\s+(\d{1,2})(?::(\d{2}))?\s*(?:uur)?\s+aan\s+(.+)",
            tekst.strip(), flags=re.IGNORECASE,
        )
        if natuurlijk:
            dag, uur_tekst, minuut_tekst, onderwerp = natuurlijk.groups()
            uur, minuut = int(uur_tekst), int(minuut_tekst or 0)
            if uur > 23 or minuut > 59 or not onderwerp.strip():
                return "Gebruik een tijd zoals 18:00."
            dagen = {"vandaag": 0, "morgen": 1, "overmorgen": 2}
            moment = (datetime.now() + timedelta(days=dagen[dag.casefold()])).replace(
                hour=uur, minute=minuut, second=0, microsecond=0
            )
            if dag.casefold() == "vandaag" and moment <= datetime.now():
                return "Dat tijdstip vandaag is al voorbij. Zeg bijvoorbeeld: herinner me morgen om 18:00 aan mijn huiswerk."
            self.gegevens["afspraken"].append({"moment": moment.isoformat(timespec="minutes"),
                                                "tekst": onderwerp.strip(), "soort": "herinnering"})
            self.bewaar(self.gegevens)
            return f"Herinnering bewaard voor {moment:%d-%m-%Y om %H:%M}: {onderwerp.strip()}."
        if klein.startswith(("afspraak: ", "herinnering: ")):
            inhoud = tekst.split(":", 1)[1].strip()
            delen = inhoud.split("|", 1)
            if len(delen) != 2 or not delen[1].strip():
                return "Gebruik: afspraak: 2026-10-01 15:00 | onderwerp"
            try:
                moment = datetime.strptime(delen[0].strip(), "%Y-%m-%d %H:%M")
            except ValueError:
                return "Gebruik een echte datum en tijd, bijvoorbeeld 2026-10-01 15:00."
            soort = "herinnering" if klein.startswith("herinnering:") else "afspraak"
            self.gegevens["afspraken"].append({"moment": moment.isoformat(timespec="minutes"), "tekst": delen[1].strip(), "soort": soort})
            self.bewaar(self.gegevens)
            return f"{soort.capitalize()} bewaard voor {moment:%d-%m-%Y %H:%M}."
        if klein in {"agenda", "herinneringen"}:
            afspraken = sorted(self.gegevens["afspraken"], key=lambda item: item["moment"])
            return "\n".join(
                f"{n}. {item['moment'].replace('T', ' ')} - {item['tekst']} ({item['soort']})"
                for n, item in enumerate(afspraken, 1)
            ) or "Je agenda is leeg."
        if klein.startswith("verwijder afspraak: "):
            nummer = klein.split(":", 1)[1].strip()
            afspraken = sorted(self.gegevens["afspraken"], key=lambda item: item["moment"])
            if not nummer.isdigit() or not 1 <= int(nummer) <= len(afspraken):
                return "Gebruik een nummer uit 'agenda'."
            verwijderd = afspraken[int(nummer) - 1]
            self.gegevens["afspraken"].remove(verwijderd)
            self.bewaar(self.gegevens)
            return f"Afspraak verwijderd: {verwijderd['tekst']}"
        return None

    def meld_herinneringen(self):
        """Toon vervallen herinneringen als het programma een beurt verwerkt."""
        nu = datetime.now()
        berichten = []
        for item in self.gegevens["afspraken"]:
            if item["soort"] == "herinnering" and not item.get("gemeld"):
                if datetime.fromisoformat(item["moment"]) <= nu:
                    berichten.append(f"Herinnering: {item['tekst']}")
                    item["gemeld"] = True
        if berichten:
            self.bewaar(self.gegevens)
        return berichten

    def zoek_internet(self, tekst, klein):
        """Open een gewone webzoekopdracht; er wordt geen AI-dienst gebruikt."""
        if not klein.startswith("zoek internet: "):
            return None
        vraag = tekst.split(":", 1)[1].strip()
        if not vraag or len(vraag) > 200:
            return "Typ een zoekopdracht van maximaal 200 tekens."
        adres = "https://www.google.com/search?q=" + quote_plus(vraag)

        def openen():
            if webbrowser.open(adres):
                return "De zoekopdracht is in je browser geopend."
            return f"De browser opende niet. Open zelf: {adres}"

        self.wacht_op_bevestiging = openen
        return f"Ik kan '{vraag}' in je browser zoeken. Daarbij verlaat je zoektekst je computer. Typ 'bevestig' of 'annuleer'."

    def open_link(self, tekst, klein):
        """Open op verzoek alleen een gewone http- of https-website."""
        opdracht = re.fullmatch(
            r"(?:open (?:deze |de )?(?:link|website)|open|ga naar)\s*:?[ \t]*(.*)",
            tekst, flags=re.IGNORECASE,
        )
        if not opdracht:
            return None
        adres = opdracht.group(1).strip()
        if adres.startswith("www."):
            adres = "https://" + adres
        if not adres or len(adres) > 2048 or any(teken.isspace() or ord(teken) < 32 for teken in adres) or "\\" in adres:
            return "Typ één volledig webadres, bijvoorbeeld: open https://www.wikipedia.org"
        try:
            onderdelen = urlsplit(adres)
            geldig = (onderdelen.scheme.lower() in {"http", "https"}
                      and bool(onderdelen.hostname) and onderdelen.username is None
                      and onderdelen.password is None and onderdelen.port != 0)
        except ValueError:
            geldig = False
        if not geldig:
            return "Ik kan alleen gewone website-links openen die met https:// of http:// beginnen."
        try:
            if webbrowser.open(adres):
                return f"Ik heb deze link in je browser geopend: {adres}"
        except (OSError, ValueError):
            pass
        return f"De browser opende niet. Je kunt de link zelf openen: {adres}"

    def website(self, tekst, klein):
        """Open een apart browservenster en lees scores na handmatig inloggen."""
        if klein.startswith("website start:"):
            adres = tekst.split(":", 1)[1].strip()
            if self.website_werk is None:
                from mikagpt_browser import WebsiteWerk
                self.website_werk = WebsiteWerk()
            return self.website_werk.start(adres)
        if klein == "website status":
            return self.website_werk.status() if self.website_werk else "Er staat nog geen website open. Typ: website start: https://apps.noordhoff.nl/..."
        if klein == "website sluit":
            if self.website_werk is not None:
                self.website_werk.sluit()
                self.website_werk = None
            return "Het aparte browservenster is gesloten."
        return None

    def sluit_browser(self):
        """Sluit de aparte browser wanneer MikaGPT stopt."""
        if self.website_werk is not None:
            self.website_werk.sluit()
            self.website_werk = None

    def map(self):
        naam = self.gegevens["actief_project"]
        veilige_naam = re.sub(r"[^\w-]", "_", naam, flags=re.UNICODE)
        return self.projectmap / veilige_naam

    def bestandspad(self, naam):
        """Sta alleen bestanden binnen de map van het actieve project toe."""
        if PureWindowsPath(naam.strip()).is_reserved():
            raise ValueError("Deze bestandsnaam is in Windows gereserveerd.")
        basis = self.map().resolve()
        pad = (basis / naam.strip()).resolve()
        if pad == basis or not pad.is_relative_to(basis):
            raise ValueError("Gebruik alleen een bestandsnaam binnen het actieve project.")
        return pad

    def _bestand_tekst(self, pad):
        """Lees veilige tekst uit een tekstbestand of PDF voor samenvatten en vragen."""
        soort = pad.suffix.lower()
        if pad.stat().st_size > MAX_BESTAND:
            raise ValueError("Dit bestand is te groot om hier te lezen.")
        if soort in TEKSTBESTANDEN:
            return pad.read_text(encoding="utf-8", errors="replace")[:12000]
        if soort == ".pdf":
            try:
                PdfReader = importlib.import_module("pypdf").PdfReader
            except ImportError as fout:
                raise ValueError("PDF-tekst lezen is nu niet beschikbaar.") from fout
            reader = PdfReader(str(pad))
            return "\n".join(page.extract_text() or "" for page in reader.pages[:30])[:12000]
        return None

    def _beschrijf_afbeelding(self, pad):
        try:
            Image = importlib.import_module("PIL.Image")
            with Image.open(pad) as afbeelding:
                breedte, hoogte = afbeelding.size
                stand = "liggend" if breedte > hoogte else "staand" if hoogte > breedte else "vierkant"
                return (f"Dit is een {stand} afbeelding van {breedte} × {hoogte} pixels ({afbeelding.format}). "
                        "Ik kan de foto bewaren en de technische informatie uitleggen. "
                        "Voor het herkennen van voorwerpen of tekst in een foto heeft MikaGPT nog beeldherkenning nodig.")
        except (ImportError, OSError) as fout:
            return f"Ik kon de afbeeldingsinformatie niet lezen: {fout}"

    def _samenvatting_van_tekst(self, inhoud, naam):
        regels = [regel.strip() for regel in inhoud.splitlines() if regel.strip()]
        zinnen = re.split(r"(?<=[.!?])\s+", " ".join(regels))
        kern = [zin for zin in zinnen if len(zin) > 20][:4]
        if not kern:
            kern = regels[:4]
        voorbeeld = "\n• ".join(kern)[:1800] or "Er is geen leesbare tekst gevonden."
        return (f"SAMENVATTING — {naam}\n\n"
                f"Dit bestand bevat ongeveer {len(inhoud.split())} woorden en {len(regels)} tekstregels.\n\n"
                f"Belangrijkste punten:\n• {voorbeeld}\n\n"
                "Je kunt nu onder de bijlage een vraag typen. MikaGPT zoekt dan het antwoord in dit bestand.")

    def bestanden(self, tekst, klein):
        if klein.startswith("bestand gebruiken: "):
            naam = tekst.split(":", 1)[1].strip()
            try:
                pad = self.bestandspad(naam)
                if not pad.is_file():
                    return "Dat bestand bestaat niet in het actieve project."
                self.actief_bestand = pad.name
                return f"'{pad.name}' is gekozen. Vraag nu gerust iets over dit bestand."
            except (OSError, ValueError) as fout:
                return f"Bestand kiezen lukte niet: {fout}"
        if klein.startswith("bestand samenvatting: "):
            naam = tekst.split(":", 1)[1].strip()
            try:
                pad = self.bestandspad(naam)
                if not pad.is_file():
                    return "Dat bestand bestaat niet in het actieve project."
                self.actief_bestand = pad.name
                inhoud = self._bestand_tekst(pad)
                if inhoud is not None:
                    return self._samenvatting_van_tekst(inhoud, pad.name)
                if pad.suffix.lower() in {".png", ".jpg", ".jpeg", ".gif", ".webp"}:
                    return self._beschrijf_afbeelding(pad)
                return f"'{pad.name}' is toegevoegd. Dit type bestand kan ik nog niet samenvatten."
            except (OSError, ValueError, UnicodeError) as fout:
                return f"Samenvatten lukte niet: {fout}"
        if klein.startswith("bestand vraag: "):
            delen = tekst.split(":", 1)[1].split("|", 1)
            if len(delen) != 2:
                return "Gebruik: bestand vraag: bestandsnaam | jouw vraag"
            naam, vraag = (deel.strip() for deel in delen)
            try:
                pad = self.bestandspad(naam)
                if not pad.is_file():
                    return "Dat bestand bestaat niet in het actieve project."
                inhoud = self._bestand_tekst(pad)
                if inhoud is None:
                    return "Over dit type bestand kan ik nog geen inhoudelijke vragen beantwoorden."
                zoekwoorden = [woord.casefold() for woord in re.findall(r"[\wÀ-ÿ]{4,}", vraag)
                               if woord.casefold() not in {"wat", "welke", "welk", "staat", "vertel", "over", "deze", "bestand", "zijn", "heeft"}]
                zinnen = re.split(r"(?<=[.!?])\s+", " ".join(inhoud.splitlines()))
                scores = [(sum(woord in zin.casefold() for woord in zoekwoorden), nummer, zin.strip())
                          for nummer, zin in enumerate(zinnen)]
                passende = [(score, nummer, zin) for score, nummer, zin in scores if score]
                if passende:
                    passende.sort(key=lambda item: (-item[0], item[1]))
                    antwoord = " ".join(item[2] for item in passende[:3])[:1800]
                    return f"In '{pad.name}' staat hierover:\n\n{antwoord}\n\nBron: {pad.name}"
                return (f"Ik vind geen duidelijk stukje over '{vraag}' in '{pad.name}'. "
                        "Probeer andere woorden, of vraag om de samenvatting opnieuw.")
            except (OSError, ValueError, UnicodeError) as fout:
                return f"Deze vraag over het bestand lukte niet: {fout}"
        if klein == "bestanden":
            basis = self.map()
            if not basis.exists():
                return "Dit project heeft nog geen bestanden."
            namen = sorted(str(p.relative_to(basis)) for p in basis.rglob("*") if p.is_file())
            return "\n".join(namen[:50]) or "Dit project heeft nog geen bestanden."
        if klein.startswith(("lees bestand: ", "bekijk bestand: ")):
            naam = tekst.split(":", 1)[1].strip()
            try:
                pad = self.bestandspad(naam)
                if not pad.is_file():
                    return "Dat bestand bestaat niet in het actieve project."
                soort = pad.suffix.lower()
                grens = MAX_BESTAND if soort in TEKSTBESTANDEN else 10_000_000
                if pad.stat().st_size > grens:
                    return "Dit bestand is te groot om hier te bekijken."
                if soort in TEKSTBESTANDEN:
                    return pad.read_text(encoding="utf-8")[:4000] or "Het bestand is leeg."
                if soort == ".pdf":
                    try:
                        PdfReader = importlib.import_module("pypdf").PdfReader
                        PdfReadError = importlib.import_module("pypdf.errors").PdfReadError
                    except ImportError:
                        return "Voor PDF-tekst is het Python-pakket pypdf nodig."
                    try:
                        reader = PdfReader(str(pad))
                        return "\n".join(page.extract_text() or "" for page in reader.pages[:20])[:4000] or "Geen selecteerbare tekst gevonden."
                    except PdfReadError:
                        return "Deze PDF kan ik niet als tekst lezen."
                if soort in {".png", ".jpg", ".jpeg", ".gif", ".webp"}:
                    try:
                        Image = importlib.import_module("PIL.Image")
                    except ImportError:
                        return "Voor afbeeldingsinformatie is het Python-pakket Pillow nodig."
                    with Image.open(pad) as afbeelding:
                        return f"Afbeelding: {afbeelding.width} x {afbeelding.height} pixels, {afbeelding.format}. Ik kan de inhoud nog niet herkennen."
                if soort == ".wav":
                    with wave.open(str(pad), "rb") as geluid:
                        frequentie = geluid.getframerate()
                        if frequentie <= 0:
                            return "Dit geluidsbestand heeft geen geldige samplefrequentie."
                        duur = geluid.getnframes() / frequentie
                        return f"Geluidsbestand van {duur:.1f} seconden. Ik kan spraak nog niet herkennen."
                return f"Bestand van {pad.stat().st_size} bytes. Voor dit type kan ik nog geen inhoud lezen."
            except (OSError, ValueError, UnicodeError, wave.Error) as fout:
                return f"Kan het bestand niet lezen: {fout}"
        if klein.startswith("maak bestand: "):
            delen = tekst[14:].split("|", 1)
            if len(delen) != 2 or not delen[0].strip():
                return "Gebruik: maak bestand: naam.txt | inhoud"
            naam, inhoud = (deel.strip() for deel in delen)
            try:
                pad = self.bestandspad(naam)
                if pad.suffix.lower() not in TEKSTBESTANDEN or len(inhoud) > 10_000:
                    return "Gebruik een klein tekstbestand (.txt, .md, .py, .json, .csv of .svg)."
                if pad.exists():
                    return "Dit bestand bestaat al. Gebruik 'vervang tekst:' voor een wijziging."
                if pad.suffix.lower() == ".py":
                    ast.parse(inhoud)
            except (OSError, ValueError, SyntaxError) as fout:
                return f"Bestand niet voorbereid: {fout}"

            def maken():
                if pad.exists():
                    return "Het bestand bestaat inmiddels al; er is niets overschreven."
                pad.parent.mkdir(parents=True, exist_ok=True)
                pad.write_text(inhoud + "\n", encoding="utf-8")
                return f"Bestand gemaakt: {naam}"

            self.wacht_op_bevestiging = maken
            return f"Nieuw bestand {naam} met inhoud:\n{inhoud[:500]}\nTyp 'bevestig' om het te maken of 'annuleer'."
        if klein.startswith("vervang tekst: "):
            delen = tekst[14:].split("|", 2)
            if len(delen) != 3 or not delen[1].strip():
                return "Gebruik: vervang tekst: naam.py | oude tekst | nieuwe tekst"
            naam, oud, nieuw = (deel.strip() for deel in delen)
            try:
                pad = self.bestandspad(naam)
                if not pad.is_file() or pad.suffix.lower() not in TEKSTBESTANDEN:
                    return "Kies een bestaand tekstbestand in het actieve project."
                origineel = pad.read_text(encoding="utf-8")
                if len(origineel) > MAX_BESTAND or oud not in origineel:
                    return "De oude tekst staat niet in dit kleine bestand."
                gewijzigd = origineel.replace(oud, nieuw, 1)
                if pad.suffix.lower() == ".py":
                    ast.parse(gewijzigd)
            except (OSError, ValueError, SyntaxError, UnicodeError) as fout:
                return f"Wijziging niet voorbereid: {fout}"

            def vervangen():
                if pad.read_text(encoding="utf-8") != origineel:
                    return "Het bestand is intussen veranderd. Probeer de wijziging opnieuw."
                kopie = pad.with_suffix(pad.suffix + ".bak")
                nummer = 2
                while kopie.exists():
                    kopie = pad.with_suffix(pad.suffix + f".bak{nummer}")
                    nummer += 1
                kopie.write_text(origineel, encoding="utf-8")
                pad.write_text(gewijzigd, encoding="utf-8")
                return f"Tekst vervangen in {naam}. Reservekopie: {kopie.name}"

            self.wacht_op_bevestiging = vervangen
            verschil = "\n".join(difflib.unified_diff(origineel.splitlines(), gewijzigd.splitlines(), fromfile="voor", tofile="na", lineterm=""))
            return f"Voorgestelde wijziging:\n{verschil[:1500]}\nTyp 'bevestig' om toe te passen of 'annuleer'."
        return None

    def code(self, tekst, klein):
        if klein.startswith("leg code uit: "):
            try:
                pad = self.bestandspad(tekst.split(":", 1)[1].strip())
                if pad.suffix.lower() != ".py" or not pad.is_file():
                    return "Kies een bestaand .py-bestand in het actieve project."
                boom = ast.parse(pad.read_text(encoding="utf-8"))
                onderdelen = []
                for knoop in boom.body:
                    if isinstance(knoop, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        onderdelen.append(f"Regel {knoop.lineno}: functie {knoop.name}()")
                    elif isinstance(knoop, ast.ClassDef):
                        onderdelen.append(f"Regel {knoop.lineno}: klasse {knoop.name}")
                    elif isinstance(knoop, (ast.Import, ast.ImportFrom)):
                        onderdelen.append(f"Regel {knoop.lineno}: gebruikt een Python-module")
                return "Opbouw van de code:\n" + "\n".join(onderdelen[:30]) if onderdelen else "Ik zie geen functies, klassen of imports; de code bestaat uit losse opdrachten."
            except (OSError, ValueError, SyntaxError, UnicodeError) as fout:
                return f"Kan de code niet lezen: {fout}"
        if klein.startswith("controleer code: "):
            try:
                pad = self.bestandspad(tekst[17:].strip())
                if pad.suffix.lower() != ".py" or not pad.is_file():
                    return "Kies een bestaand .py-bestand in het actieve project."
                ast.parse(pad.read_text(encoding="utf-8"))
                return "De Python-syntaxis is in orde. Dit controleert nog niet of de code doet wat je wilt."
            except (OSError, ValueError, SyntaxError, UnicodeError) as fout:
                return f"Codecontrole vond een fout: {fout}"
        if klein.startswith(("voer code uit: ", "test code: ", "test uitvoer: ")):
            verwacht = None
            naam = tekst.split(":", 1)[1].strip()
            if klein.startswith("test uitvoer: "):
                delen = naam.split("|", 1)
                if len(delen) != 2:
                    return "Gebruik: test uitvoer: bestand.py | verwachte tekst"
                naam, verwacht = (deel.strip() for deel in delen)
            try:
                pad = self.bestandspad(naam)
                if pad.suffix.lower() != ".py" or not pad.is_file():
                    return "Kies een bestaand .py-bestand in het actieve project."
            except (OSError, ValueError) as fout:
                return f"Kan code niet voorbereiden: {fout}"

            def uitvoeren():
                resultaat = subprocess.run(
                    [sys.executable, str(pad)], cwd=self.map(), capture_output=True,
                    text=True, timeout=5, check=False,
                )
                uitvoer = (resultaat.stdout + resultaat.stderr)[:3000].strip()
                if verwacht is not None:
                    geslaagd = resultaat.returncode == 0 and resultaat.stdout.strip() == verwacht
                    status = "GESLAAGD" if geslaagd else "MISLUKT"
                    return f"Test {status}. Verwacht: {verwacht!r}. Gekregen: {resultaat.stdout.strip()!r}. {resultaat.stderr[:1000]}"
                return f"Eindcode {resultaat.returncode}. Uitvoer:\n{uitvoer or '(geen uitvoer)'}"

            self.wacht_op_bevestiging = uitvoeren
            return f"Je staat op het punt {pad.name} als Python-programma uit te voeren. Typ 'bevestig' of 'annuleer'."
        return None

    def fout_uitleg(self, tekst, klein):
        """Leg een paar veelvoorkomende Python-fouten in gewone taal uit."""
        if not klein.startswith("analyseer fout: "):
            return None
        fout = tekst.split(":", 1)[1].strip()
        uitleg = {
            "syntaxerror": "Er staat een schrijffout in de Python-code. Controleer haakjes, aanhalingstekens en dubbele punten.",
            "nameerror": "Python kent een gebruikte naam niet. Controleer de spelling en of de variabele eerst is gemaakt.",
            "typeerror": "Een bewerking krijgt een verkeerd soort waarde, bijvoorbeeld tekst waar een getal verwacht wordt.",
            "filenotfounderror": "Het bestandspad klopt niet of het bestand bestaat nog niet.",
            "zerodivisionerror": "Je probeert door nul te delen.",
            "indentationerror": "De spaties aan het begin van regels kloppen niet. Controleer de inspringing.",
        }
        for naam, antwoord in uitleg.items():
            if naam in fout.lower():
                return antwoord
        return "Ik herken deze fout nog niet. Gebruik 'leer: vraag | antwoord' om mij nieuwe uitleg te leren."

    def poster(self, tekst, klein):
        if not klein.startswith("poster: "):
            return None
        delen = tekst[8:].split("|", 1)
        titel = delen[0].strip()[:80]
        ondertitel = delen[1].strip()[:120] if len(delen) == 2 else "Gemaakt met MikaGPT"
        if not titel:
            return "Gebruik: poster: titel | ondertitel"
        inhoud = (
            '<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="600" viewBox="0 0 1000 600">\n'
            '<rect width="1000" height="600" fill="#15294b"/>\n'
            '<circle cx="850" cy="120" r="210" fill="#315f9b" opacity=".5"/>\n'
            f'<text x="70" y="290" fill="white" font-family="Arial" font-size="56">{html.escape(titel)}</text>\n'
            f'<text x="75" y="360" fill="#a9d1ff" font-family="Arial" font-size="30">{html.escape(ondertitel)}</text>\n'
            '</svg>\n'
        )
        basis = self.map()
        nummer = 1
        while (basis / f"poster-{nummer}.svg").exists():
            nummer += 1
        pad = basis / f"poster-{nummer}.svg"

        def maken():
            basis.mkdir(parents=True, exist_ok=True)
            if pad.exists():
                return "Die poster bestaat inmiddels al. Probeer opnieuw."
            pad.write_text(inhoud, encoding="utf-8")
            return f"Poster gemaakt: {pad}"

        self.wacht_op_bevestiging = maken
        return f"Poster met titel '{titel}' voorbereid. Typ 'bevestig' of 'annuleer'."

    def afbeelding(self, tekst, klein):
        """Bewerk een eigen afbeelding met eenvoudige, lokale beeldbewerkingen."""
        if not klein.startswith("afbeelding bewerk: "):
            return None
        delen = tekst[19:].split("|", 1)
        if len(delen) != 2:
            return "Gebruik: afbeelding bewerk: foto.png | grijs (of draai, spiegel)"
        naam, bewerking = (deel.strip() for deel in delen)
        bewerking = bewerking.lower()
        if bewerking not in {"grijs", "draai", "spiegel"}:
            return "Kies 'grijs', 'draai' of 'spiegel'."
        try:
            bron = self.bestandspad(naam)
            if not bron.is_file() or bron.suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp"}:
                return "Kies een bestaande PNG-, JPG- of WebP-afbeelding in het actieve project."
            if bron.stat().st_size > 10_000_000:
                return "Deze afbeelding is te groot. Gebruik maximaal 10 MB."
            Image = importlib.import_module("PIL.Image")
            ImageOps = importlib.import_module("PIL.ImageOps")
            with Image.open(bron) as foto:
                if foto.width * foto.height > 20_000_000:
                    return "Deze afbeelding heeft te veel pixels."
                foto.verify()
        except ImportError:
            return "Voor afbeeldingsbewerking is het Python-pakket Pillow nodig."
        except (OSError, ValueError) as fout:
            return f"Kan afbeelding niet voorbereiden: {fout}"

        doel = bron.with_name(f"{bron.stem}-{bewerking}.png")
        if doel.exists():
            return f"{doel.name} bestaat al. Hernoem of verplaats die eerst."

        def bewerken():
            if doel.exists():
                return "Het doelbestand bestaat inmiddels al. Probeer opnieuw."
            with Image.open(bron) as foto:
                if bewerking == "grijs":
                    resultaat = ImageOps.grayscale(foto)
                elif bewerking == "draai":
                    resultaat = foto.rotate(90, expand=True)
                else:
                    resultaat = ImageOps.mirror(foto)
                resultaat.save(doel)
            return f"Afbeelding gemaakt: {doel.name}"

        self.wacht_op_bevestiging = bewerken
        return f"Bewerking '{bewerking}' van {bron.name} voorbereid. Typ 'bevestig' of 'annuleer'."
