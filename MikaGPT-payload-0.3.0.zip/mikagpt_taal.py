"""Eenvoudig begrip van nieuwe Nederlandse zinnen zonder ander AI-model.

Dit onderdeel zoekt naar woorden en hun rol in een vraag. Het probeert geen
antwoord te verzinnen wanneer een betekenis of eigenschap nog niet geleerd is.
"""

import re
import random


EIGENSCHAPPEN = {
    "grootte": {"groot", "grote", "grootte", "afmeting", "afmetingen", "hoog", "hoogte", "breed", "breedte", "lang", "lengte"},
    "gewicht": {"zwaar", "gewicht", "weegt", "wegen"},
    "inhoud": {"inhoud", "volume", "liter", "milliliter", "passen", "past"},
    "kleur": {"kleur", "kleuren", "gekleurd"},
}
BIJWOORDEN = {"gemiddeld", "ongeveer", "eigenlijk", "precies", "meestal", "normaal"}
KLEINE_WOORDEN = {"een", "de", "het", "die", "dat", "dit", "van", "voor", "over", "met", "in", "is", "zijn", "wat", "hoe", "welke", "welk", "er", "kan", "kun", "je", "jij", "ik", "mijn", "naar", "als"}

# Een paar gecontroleerde basisbetekenissen. Bij andere woorden vraagt MikaGPT
# om uitleg of gebruikt hij zijn lokale taalmodel; hij verzint hier geen definitie.
BASISBETEKENISSEN = {
    "kaas": "een voedingsmiddel dat van melk wordt gemaakt",
    "pizza": "een gerecht van gebakken deeg met beleg, vaak tomatensaus en kaas",
}


def woorden(tekst):
    """Haal leestekens weg, maar bewaar de volgorde van de woorden."""
    return re.findall(r"[^\W\d_]+|\d+", tekst.casefold(), flags=re.UNICODE)


def eigenschap_van_vraag(delen):
    """Herken het onderwerp van een eigenschapsvraag via losse woorden."""
    aanwezig = set(delen)
    for naam, varianten in EIGENSCHAPPEN.items():
        if aanwezig & varianten:
            return naam
    # Bijvoorbeeld: 'Hoeveel kan er in een fles?' gaat over de inhoud.
    if "hoeveel" in aanwezig and ("in" in aanwezig or "erin" in aanwezig):
        return "inhoud"
    return None


def zoek_onderwerp(delen, woordenboek):
    """Zoek het voorwerp achter een lidwoord, of anders een geleerd woord."""
    for i, deel in enumerate(delen[:-1]):
        if deel in {"een", "de", "het", "die", "dit", "mijn"}:
            kandidaten = [woord for woord in delen[i + 1:] if woord not in KLEINE_WOORDEN | BIJWOORDEN]
            if kandidaten:
                return kandidaten[-1]
    vraagwoorden = set().union(*EIGENSCHAPPEN.values()) | KLEINE_WOORDEN | {"maak", "schrijf", "gebruik", "bedenk", "zin", "betekent", "betekenis", "leg", "uit"}
    for woord in sorted(woordenboek, key=len, reverse=True):
        woorddelen = woorden(woord)
        if set(woorddelen) & vraagwoorden:
            continue
        if any(delen[i:i + len(woorddelen)] == woorddelen for i in range(len(delen) - len(woorddelen) + 1)):
            return woord
    if {"wat", "hoe", "welke", "welk", "maak", "schrijf", "gebruik", "bedenk"} & set(delen):
        kandidaten = [woord for woord in delen if woord.isalpha() and woord not in vraagwoorden | BIJWOORDEN]
        if kandidaten:
            return kandidaten[-1]
    return None


def is_betekenisvraag(delen, onderwerp):
    """Maak van een gewone feitenvraag geen vraag naar een woordbetekenis."""
    if "betekent" in delen or "betekenis" in delen:
        return True
    if "leg" in delen and "uit" in delen:
        return True
    if "wat" not in delen or "is" not in delen:
        return False
    wat = delen.index("wat")
    is_woord = delen.index("is")
    if onderwerp not in delen:
        return False
    ding = delen.index(onderwerp)
    # 'Wat is een lamp?' en 'Kun je uitleggen wat een lamp is?'
    # 'Wat is de hoofdstad van Frankrijk?' valt hier bewust buiten.
    als_definitie = wat < is_woord < ding and ding - is_woord <= 3
    als_uitleg = wat < ding < is_woord and ding - wat <= 3
    overige = [woord for woord in delen[min(wat, is_woord):] if woord not in KLEINE_WOORDEN | BIJWOORDEN and woord != onderwerp]
    return (als_definitie or als_uitleg) and not overige


def antwoord_op_onbekend(invoer, vorige_vraag="", antwoordstijl="normaal"):
    """Reageer kort en eerlijk wanneer MikaGPT een bericht nog niet begrijpt."""
    delen = woorden(invoer)
    if not delen:
        return "Ik heb geen tekst ontvangen."
    if woorden(vorige_vraag) == delen:
        return "Je vroeg dit net ook. Ik heb er helaas nog geen beter antwoord op. Misschien kun je het anders formuleren?"

    vraagwoorden = {"wat", "hoe", "waar", "waarom", "wanneer", "wie", "welke", "welk", "hoeveel"}
    is_vraag = "?" in invoer or bool(vraagwoorden & set(delen))
    if "waarom" in delen:
        antwoord = "Ik kan de reden daarvoor nog niet betrouwbaar uitleggen."
    elif "wanneer" in delen:
        antwoord = "Die datum of tijd weet ik niet zeker."
    elif "waar" in delen:
        antwoord = "Die plek kan ik nog niet bepalen."
    elif "wie" in delen:
        antwoord = "Dat weet ik niet zeker over die persoon."
    elif "hoe" in delen:
        antwoord = "Ik weet nog niet goed hoe dat zit."
    elif is_vraag:
        antwoord = "Daar heb ik nog geen betrouwbaar antwoord op."
    elif delen[0] in {"maak", "schrijf", "zoek", "vertel", "geef", "doe"}:
        antwoord = "Die opdracht kan ik nu nog niet uitvoeren."
    else:
        antwoord = "Ik heb je bericht gelezen, maar ik weet nog niet wat je van mij verwacht."

    if antwoordstijl == "kort":
        return antwoord
    if is_vraag:
        return antwoord + " Kun je je vraag iets anders formuleren?"
    return antwoord + " Je kunt me ook een concrete vraag stellen."


INSTEMMINGEN = {"ja", "jazeker", "zeker", "tuurlijk", "natuurlijk", "graag", "ja graag",
                "ok", "oke", "oké", "prima", "vind ik goed", "ik vind het goed",
                "is goed", "goed idee", "klinkt goed"}
AFWIJZINGEN = {"nee", "nee bedankt", "nee dankje", "liever niet", "niet nodig",
               "hoeft niet", "nee hoor", "niet echt"}
TWIJFELS = {"misschien", "weet ik niet", "geen idee", "ik denk het niet"}


def soort_kort_antwoord(bericht):
    """Herken gewone manieren om ja, nee of twijfel te zeggen."""
    tekst = bericht.casefold().strip().strip("!?., ")
    if tekst in INSTEMMINGEN:
        return "ja"
    if tekst in AFWIJZINGEN:
        return "nee"
    if tekst in TWIJFELS:
        return "twijfel"
    return None


def antwoord_op_kort_bericht(bericht, vorige_antwoord=""):
    """Reageer op een korte reactie volgens MikaGPT's vorige vraag."""
    soort = soort_kort_antwoord(bericht)
    vorig = vorige_antwoord.casefold()
    if "anders formuleren" in vorig:
        opties = (["Prima, probeer het gerust met andere woorden.",
                   "Goed, stel je vraag maar opnieuw."] if soort == "ja" else
                  ["Geen haast. Probeer het wanneer je wilt opnieuw."] if soort == "twijfel" else
                  ["Geen probleem. We kunnen ook over iets anders praten.",
                   "Dat hoeft niet. Stel gerust een andere vraag."])
    elif "wil je nog iets vragen" in vorig:
        opties = (["Ja hoor, stel je vraag maar.", "Natuurlijk. Wat wil je weten?"]
                  if soort == "ja" else ["Geen haast. Je kunt ook later iets vragen."]
                  if soort == "twijfel" else ["Prima, dan laten we het hierbij.", "Goed, zeg het maar als je later iets wilt vragen."])
    elif vorig.rstrip().endswith("?"):
        # Een open vraag, zoals 'Hoe kan ik je helpen?', vraagt om meer uitleg.
        opties = (["Vertel maar wat je bedoelt.", "Waarmee zal ik je helpen?"]
                  if soort == "ja" else ["Geen haast. Denk er rustig over na."]
                  if soort == "twijfel" else ["Geen probleem. Zeg het maar wanneer je verder wilt.",
                                           "Prima, dan laten we het even rusten."])
    elif soort == "nee":
        opties = ["Geen probleem. Waar wil je het wel over hebben?",
                  "Prima. We kunnen ook iets anders bespreken."]
    elif soort == "twijfel":
        opties = ["Geen haast. Vertel maar als je verder wilt.",
                  "Dat is prima. We kunnen later verder praten."]
    else:
        opties = ["Oké. Vertel maar waar je het over wilt hebben.",
                  "Prima. Waarmee kan ik je nu helpen?",
                  "Goed. Wil je nog iets vragen?",
                  "Helder. Vertel maar verder."]
    return random.choice([antwoord for antwoord in opties if antwoord != vorige_antwoord] or opties)


def verwerk_taalvraag(invoer, gegevens, bewaar):
    """Behandel leren en nieuwe vraagformuleringen; geef anders None terug."""
    tekst = invoer.strip()
    klein = tekst.casefold()
    woordenboek = gegevens["woordenboek"]

    # De gebruiker kan een nieuw woord leren zonder programmawijziging.
    if klein.startswith("leer woord:"):
        delen = tekst[len("leer woord:"):].split("|", 1)
        if len(delen) != 2 or not all(deel.strip() for deel in delen):
            return "Gebruik: leer woord: fles | een houder voor vloeistof"
        woord, betekenis = (deel.strip() for deel in delen)
        if len(woorden(woord)) != 1 or len(woord) > 40 or len(betekenis) > 300:
            return "Gebruik één woord en een korte betekenis."
        sleutel = woord.casefold()
        item = woordenboek.setdefault(sleutel, {"betekenis": "", "eigenschappen": {}})
        item["betekenis"] = betekenis.rstrip(".! ")
        bewaar(gegevens)
        return f"Ik heb geleerd wat '{woord}' betekent."

    # Eigenschappen zijn aparte feiten: een betekenis alleen vertelt geen grootte.
    if klein.startswith("leer eigenschap:"):
        delen = tekst[len("leer eigenschap:"):].split("|", 2)
        if len(delen) != 3 or not all(deel.strip() for deel in delen):
            return "Gebruik: leer eigenschap: fles | inhoud | verschilt per fles"
        woord, naam, waarde = (deel.strip() for deel in delen)
        sleutel = woord.casefold()
        if sleutel not in woordenboek:
            return f"Leer mij eerst wat '{woord}' betekent met: leer woord: {woord} | betekenis"
        eigenschap = eigenschap_van_vraag(woorden(naam))
        if eigenschap is None or len(waarde) > 300:
            return "Kies als eigenschap: grootte, gewicht, inhoud of kleur. Gebruik een korte uitleg."
        woordenboek[sleutel]["eigenschappen"][eigenschap] = waarde.rstrip(".! ")
        bewaar(gegevens)
        return f"Ik heb de {eigenschap} van '{woord}' onthouden."

    if klein.startswith("vergeet woord:"):
        woord = tekst[len("vergeet woord:"):].strip().casefold()
        if woord not in woordenboek:
            return "Dat woord heb ik niet geleerd."
        del woordenboek[woord]
        bewaar(gegevens)
        return f"Ik ben het woord '{woord}' vergeten."

    delen = woorden(tekst)
    if not delen:
        return None
    # Een los woord is meestal een vervolgvraag over de betekenis ervan.
    # Geef alleen een definitie als die lokaal bekend is.
    if len(delen) == 1:
        woord = delen[0]
        item = woordenboek.get(woord)
        betekenis = item.get("betekenis") if item else BASISBETEKENISSEN.get(woord)
        if betekenis:
            return f"{woord.capitalize()} is {betekenis}."
        return f"Wat wil je weten over '{woord}'?"
    onderwerp = zoek_onderwerp(delen, woordenboek)
    if onderwerp is None:
        return None

    # Herken een verzoek om een zin, ook als de woordvolgorde anders is.
    if "zin" in delen and ({"maak", "schrijf", "gebruik", "bedenk"} & set(delen)):
        item = woordenboek.get(onderwerp)
        if not item or not item["betekenis"]:
            return f"Ik weet nog niet wat '{onderwerp}' betekent. Leer mij dat eerst met: leer woord: {onderwerp} | betekenis"
        return f"Een {onderwerp} is {item['betekenis']}."

    # Vraag naar een eigenschap: dezelfde losse woorden werken in meerdere zinnen.
    eigenschap = eigenschap_van_vraag(delen)
    is_vraag = bool({"wat", "hoe", "hoeveel", "welke", "welk"} & set(delen))
    if eigenschap and is_vraag:
        item = woordenboek.get(onderwerp)
        waarde = item["eigenschappen"].get(eigenschap) if item else None
        lidwoord = "het" if eigenschap == "gewicht" else "de"
        if waarde:
            return f"{lidwoord.capitalize()} {eigenschap} van een {onderwerp}: {waarde}."
        if eigenschap == "grootte":
            return f"Ik begrijp dat je naar de grootte van een {onderwerp} vraagt, maar ik weet niet welke {onderwerp} of afmetingen je bedoelt."
        return f"Ik begrijp dat je naar {lidwoord} {eigenschap} van een {onderwerp} vraagt, maar dat weet ik nog niet."

    # Vraag naar betekenis, zonder een volledige zin te hoeven herkennen.
    betekenisvraag = is_betekenisvraag(delen, onderwerp)
    if betekenisvraag:
        item = woordenboek.get(onderwerp)
        betekenis = item.get("betekenis") if item else BASISBETEKENISSEN.get(onderwerp)
        if betekenis:
            return f"'{onderwerp}' betekent: {betekenis}."
        return f"Ik weet nog niet wat '{onderwerp}' betekent. Leer mij dat met: leer woord: {onderwerp} | betekenis"
    return None
