"""Een kleine, controleerbare Wikipedia-bron voor feitelijke vragen."""

import json
import re
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
from urllib.request import ProxyHandler, Request, build_opener


API = "https://nl.wikipedia.org/w/api.php"
VERBINDING = build_opener(ProxyHandler({}))
KOPPEN = (
    "wat is", "wie is", "waar is", "waar ligt", "wanneer was", "wanneer is",
    "hoe groot is", "hoe oud is", "welke kleur heeft", "welke kleur is", "wat is de kleur van",
    "vertel over", "leg uit wat", "leg uit hoe", "hoe werkt", "hoe werken",
    "wat betekent", "wat zijn", "wie zijn", "hoeveel",
)
VOORNAAMWOORDEN = {"dat", "die", "dit", "het", "ze", "hij", "zij"}
GEEN_ONDERWERPEN = {
    "hoi", "hallo", "hey", "ja", "nee", "ok", "oke", "oké", "prima",
    "dankjewel", "bedankt", "doei", "help", "hulp", "taken", "projecten",
    "geheugen", "instellingen", "stop", "annuleer", "bevestig",
}
GEEN_KENNIS_BEGINNEN = (
    "ik ", "mijn ", "jij ", "je ", "kun je ", "kan je ", "wil je ",
    "maak ", "schrijf ", "doe ", "help me", "herinner ", "zet ",
)


def _vraag(url):
    verzoek = Request(url, headers={"User-Agent": "MikaGPT/0.1 (persoonlijk leerproject)"})
    with VERBINDING.open(verzoek, timeout=10) as reactie:
        return json.load(reactie)


def _woorden(tekst):
    return re.findall(r"[^\W\d_]+", tekst.casefold(), re.UNICODE)


def _is_kennisvraag(tekst):
    klein = tekst.casefold().strip("!?., ")
    if klein.startswith(GEEN_KENNIS_BEGINNEN):
        return False
    if any(klein.startswith(kop) for kop in KOPPEN):
        return not any(deel in klein for deel in ("mijn naam", "jouw naam", "je naam", "kun je", "kan je"))

    # Iemand typt vaak alleen een onderwerp, zoals "kaas" of "de Eiffeltoren".
    # Dat is een nuttige Wikipedia-zoekopdracht, maar gewone gesprekswoorden en
    # opdrachten mogen niet per ongeluk naar Wikipedia gaan.
    woorden = _woorden(klein)
    return (
        1 <= len(woorden) <= 5
        and klein not in GEEN_ONDERWERPEN
        and not any(klein.startswith(begin) for begin in (
            "taak", "notitie", "onthoud", "project", "open", "ga naar",
            "reken", "leer", "vergeet", "zoek internet", "website",
        ))
    )


def _onderwerp(tekst):
    """Haal het onderwerp uit eenvoudige Nederlandse kennisvragen."""
    klein = tekst.casefold().strip("!?., ")
    for kop in sorted(KOPPEN, key=len, reverse=True):
        if klein.startswith(kop):
            rest = tekst.strip()[len(kop):].strip(" ?!.,")
            return re.sub(r"^(de|het|een)\s+", "", rest, flags=re.IGNORECASE)
    # Bij een los onderwerp is de volledige invoer de zoekterm.
    return tekst.strip(" ?!.,")


def _onderwerp_uit_gesprek(gesprek):
    """Zoek het laatste duidelijke onderwerp voor vragen als 'welke kleur is dat?'."""
    for item in reversed(gesprek[-12:]):
        vraag = item.get("vraag", "")
        if not _is_kennisvraag(vraag):
            continue
        onderwerp = _onderwerp(vraag)
        if onderwerp and not set(_woorden(onderwerp)) <= VOORNAAMWOORDEN:
            return onderwerp
    return ""


def _vind_pagina(zoekterm):
    parameters = urlencode({
        "action": "query", "list": "search", "srsearch": zoekterm,
        "srnamespace": "0", "srlimit": "5", "format": "json", "formatversion": "2",
    })
    resultaten = _vraag(f"{API}?{parameters}").get("query", {}).get("search", [])
    if not resultaten:
        return None
    woorden = set(_woorden(zoekterm))
    # Bij 'aarde' is de titel zelf een doorverwijspagina. De planeetpagina
    # geeft het antwoord waar een gewone kennisvraag vrijwel altijd om vraagt.
    for resultaat in resultaten:
        titel = resultaat.get("title", "")
        if titel.casefold() == f"{zoekterm.casefold()} (planeet)":
            return titel
    for resultaat in resultaten:
        if woorden <= set(_woorden(resultaat.get("title", ""))):
            return resultaat["title"]
    return resultaten[0].get("title")


def _lees_pagina(titel):
    parameters = urlencode({
        "action": "query", "prop": "extracts", "titles": titel,
        "explaintext": "1", "exchars": "6000", "format": "json", "formatversion": "2",
    })
    pagina = _vraag(f"{API}?{parameters}").get("query", {}).get("pages", [{}])[0]
    return pagina.get("title", titel), pagina.get("extract", "").strip()


def _passende_samenvatting(tekst, vraag, antwoordstijl):
    """Kies een natuurlijke lengte uit de beschikbare broninformatie.

    Dit werkt met een tekenbudget in plaats van een vast aantal zinnen. Een
    lange pagina met een brede vraag kan daardoor uitgebreider worden dan een
    korte pagina of een heel gerichte vraag.
    """
    schone_tekst = " ".join(tekst.split())
    zinnen = re.split(r"(?<=[.!?])\s+", schone_tekst)
    vraag_klein = vraag.casefold()
    brede_vraag = any(deel in vraag_klein for deel in (
        "vertel over", "leg uit", "hoe werkt", "waarom", "geschiedenis", "alles over"
    ))
    bronlengte = len(schone_tekst)
    if antwoordstijl == "kort":
        doel = min(360, max(130, bronlengte // 14))
    elif antwoordstijl == "uitgebreid":
        doel = min(3500, max(1000, int(bronlengte * (0.7 if brede_vraag else 0.5))))
    else:
        doel = min(1300, max(350, int(bronlengte * (0.3 if brede_vraag else 0.2))))

    gekozen = []
    lengte = 0
    for zin in zinnen:
        if not zin:
            continue
        gekozen.append(zin)
        lengte += len(zin) + 1
        if lengte >= doel:
            break
    return " ".join(gekozen).strip()


def _maak_duidelijke_uitleg(antwoord, antwoordstijl):
    """Zet langere bronantwoorden in een vorm die prettig leest in de chat.

    We voegen geen verzonnen voorbeelden of stappen toe. Een voorbeeld verschijnt
    alleen wanneer het al in de betrouwbare brontekst staat.
    """
    if antwoordstijl == "kort":
        return antwoord
    zinnen = [zin.strip() for zin in re.split(r"(?<=[.!?])\s+", antwoord) if zin.strip()]
    if len(zinnen) < 3:
        return antwoord
    kern = " ".join(zinnen[:2])
    voorbeeld = next((zin for zin in zinnen[2:] if "bijvoorbeeld" in zin.casefold()), "")
    overige = [zin for zin in zinnen[2:] if zin != voorbeeld]
    delen = ["KORTE UITLEG\n" + kern]
    if overige:
        delen.append("MEER UITLEG\n" + " ".join(overige))
    if voorbeeld:
        delen.append("VOORBEELD\n" + voorbeeld)
    delen.append("SAMENVATTING\n" + zinnen[0])
    return "\n\n".join(delen)


def antwoord_van_wikipedia(vraag, gesprek, antwoordstijl="normaal"):
    """Geef een bronantwoord of None wanneer Wikipedia hier niet past."""
    if not _is_kennisvraag(vraag):
        return None
    onderwerp = _onderwerp(vraag)
    woorden = set(_woorden(onderwerp))
    if not onderwerp or woorden <= VOORNAAMWOORDEN:
        onderwerp = _onderwerp_uit_gesprek(gesprek)
    if not onderwerp:
        return "Ik weet niet waar 'dat' naar verwijst. Noem nog even het onderwerp."
    try:
        titel = _vind_pagina(onderwerp)
        if not titel:
            return "Ik vond geen passende Wikipedia-pagina voor die vraag."
        titel, tekst = _lees_pagina(titel)
    except (HTTPError, URLError, TimeoutError, OSError, ValueError, KeyError):
        return "Ik kon Wikipedia nu niet bereiken. Probeer het later nog eens."
    if not tekst:
        return f"Ik vond de pagina '{titel}', maar geen leesbare samenvatting."

    vraagwoorden = set(_woorden(vraag))
    if "kleur" in vraagwoorden and titel.casefold().startswith("aarde"):
        water = re.search(r"(\d{1,3})%\s+bedekt met water", tekst, re.IGNORECASE)
        deel = f"{water.group(1)}% van het aardoppervlak bedekt is met water" if water else "veel van het aardoppervlak uit oceanen bestaat"
        kort = f"De Aarde lijkt vanuit de ruimte vooral blauw, omdat {deel}."
        normaal = (kort + " Daarnaast zie je witte wolken en stukken land die groen, bruin of geel kunnen lijken.")
        uitgebreid = (normaal + " De kleur verandert dus als je naar oceanen, wolken, land of de atmosfeer kijkt. "
                      + _passende_samenvatting(tekst, vraag, "uitgebreid"))
        antwoord = {"kort": kort, "normaal": normaal, "uitgebreid": uitgebreid}.get(antwoordstijl, normaal)
    else:
        antwoord = _passende_samenvatting(tekst, vraag, antwoordstijl)
    antwoord = _maak_duidelijke_uitleg(antwoord, antwoordstijl)
    link = "https://nl.wikipedia.org/wiki/" + quote(titel.replace(" ", "_"))
    return f"{antwoord}\n\nBron: Wikipedia – {titel}\n{link}"
