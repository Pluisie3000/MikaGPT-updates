"""Lokaal Frans-Nederlands woordenboek voor de vier oefenrichtingen."""

import re


def sleutel(tekst):
    """Vergelijk woorden zonder verschil in hoofdletters of extra spaties."""
    return " ".join(tekst.split()).casefold()


def opdracht(tekst, gegevens, bewaar):
    """Behandel Franse leer- en overhoorvragen; geef anders None terug."""
    klein = tekst.casefold().strip()
    woorden = gegevens["franse_woorden"]

    if klein == "frans woorden":
        if not woorden:
            return "Ik ken nog geen Franse woorden. Voeg er een toe met: frans leer: quelque chose | iets"
        regels = [f"{frans} = {nederlands}" for frans, nederlands in sorted(woorden.items())]
        return "Mijn Franse woorden:\n" + "\n".join(regels)

    if klein.startswith("frans leer:"):
        delen = tekst.split(":", 1)[1].split("|")
        if len(delen) != 2 or not all(deel.strip() for deel in delen):
            return "Typ: frans leer: Frans woord | Nederlands woord"
        frans, nederlands = (" ".join(deel.split()) for deel in delen)
        if len(frans) > 100 or len(nederlands) > 100:
            return "Gebruik per kant maximaal 100 tekens."
        bestaand = next((woord for woord in woorden if sleutel(woord) == sleutel(frans)), None)
        if bestaand is not None and bestaand != frans:
            del woorden[bestaand]
        woorden[frans] = nederlands
        bewaar(gegevens)
        return f"Geleerd: {frans} = {nederlands}. Ik kan dit in beide richtingen gebruiken."

    if klein.startswith("frans vergeet:"):
        gezocht = sleutel(tekst.split(":", 1)[1])
        gevonden = next((woord for woord in woorden if sleutel(woord) == gezocht), None)
        if gevonden is None:
            return "Dat Franse woord staat niet in mijn woordenlijst."
        del woorden[gevonden]
        bewaar(gegevens)
        return f"Ik ben '{gevonden}' vergeten."

    match = re.fullmatch(r"(leren|overhoren)\s+(f\s*-\s*n|n\s*-\s*f)\s*:\s*(.*)", tekst, re.IGNORECASE | re.DOTALL)
    if not match:
        return None
    soort, richting, inhoud = match.groups()
    richting = richting.replace(" ", "").casefold()
    delen = [deel.strip() for deel in inhoud.split("|")]
    if not delen[0]:
        return "Zet de vraag achter de dubbele punt."
    if soort.casefold() == "leren" and (len(delen) < 2 or not all(delen)):
        return "Bij leren typ je de vraag en daarna de antwoordkeuzes, gescheiden door |."
    if soort.casefold() == "overhoren" and len(delen) != 1:
        return "Bij overhoren typ je alleen het woord dat op het scherm staat."

    vraag = sleutel(delen[0])
    if richting == "f-n":
        antwoorden = [nederlands for frans, nederlands in woorden.items() if sleutel(frans) == vraag]
    else:
        antwoorden = [frans for frans, nederlands in woorden.items() if sleutel(nederlands) == vraag]
    unieke_antwoorden = {sleutel(antwoord): antwoord for antwoord in antwoorden}
    if not unieke_antwoorden:
        return f"Ik weet nog niet wat '{delen[0]}' betekent. Leer het me met: frans leer: Frans woord | Nederlands woord"

    if soort.casefold() == "leren":
        opties = delen[1:]
        passend = [optie for optie in opties if sleutel(optie) in unieke_antwoorden]
        if len(passend) == 1:
            return f"Kies: {passend[0]}"
        if len(passend) > 1:
            return "Er passen meerdere keuzes bij mijn woordenlijst; ik kan dit niet betrouwbaar kiezen."
        return "Geen van de antwoordkeuzes staat als juiste vertaling in mijn woordenlijst. Ik wil niet gokken."

    if len(unieke_antwoorden) != 1:
        return "Ik ken meerdere vertalingen voor dit woord. Ik kan niet zien welke deze opdracht verwacht."
    return f"Typ: {next(iter(unieke_antwoorden.values()))}"
