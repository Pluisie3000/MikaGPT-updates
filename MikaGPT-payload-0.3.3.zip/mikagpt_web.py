"""Lokale webpagina voor het bestaande MikaGPT-programma.

De webserver start `test AI Model.py` als een gewoon Python-proces. Daardoor
gebruikt de browser exact dezelfde antwoorden en hetzelfde gegevensbestand als
de terminalversie. Alleen deze computer kan de server bereiken.
"""

import base64
import json
import os
import queue
import random
import hashlib
import hmac
import secrets
import subprocess
import sys
import threading
import time
import webbrowser
import zipfile
import re
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import ProxyHandler, Request, build_opener


# De vaste MikaGPT-runtime kan de app-code uit een los updatepakket laden.
# Tijdens ontwikkelen of in de oude losse .exe blijft de bestaande map gelden.
PAYLOADMAP = os.environ.get("MIKAGPT_PAYLOAD_DIR")
BRONMAP = Path(PAYLOADMAP) if PAYLOADMAP else Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
DATAMAP = (Path(sys.executable).resolve().parent if getattr(sys, "frozen", False)
           else BRONMAP)
SCRIPT = BRONMAP / "test AI Model.py"
HTML = BRONMAP / "mikagpt_web.html"
LOGO = BRONMAP / "mikagpt_logo.png"
TOEGANG = DATAMAP / "mikagpt_toegang.json"
ACCOUNTS = DATAMAP / "mikagpt_accounts.json"
# Standaard alleen deze laptop. Voor gebruik op dezelfde wifi kan de starter
# MIKAGPT_BIND_HOST=0.0.0.0 instellen; er komt dan geen openbare internetpoort.
HOST = os.environ.get("MIKAGPT_BIND_HOST", "127.0.0.1")
PORT = int(os.environ.get("MIKAGPT_PORT", "8765"))
MAX_UPLOAD = 2_000_000
TOEGESTANE_BESTANDEN = {".txt", ".md", ".py", ".json", ".csv", ".svg", ".pdf", ".png", ".jpg", ".jpeg", ".webp"}
ADRES_HOST = os.environ.get("MIKAGPT_ADRES_HOST", HOST)
ADRES = f"http://{ADRES_HOST}:{PORT}"
TOEGESTANE_ORIGINS = {ADRES, f"http://localhost:{PORT}"}
SESSIES = {}
VERSIE = "0.3.3"
UPDATECONFIG = DATAMAP / "mikagpt_update.json"
UPDATEVERBINDING = build_opener(ProxyHandler({}))
ACCOUNT_SLOT = threading.Lock()
EIGENAAR_SLOT = threading.Lock()
ACCOUNT_PROCESSEN = {}


def laad_toegang():
    """Maak één geheime toegangscode; alleen de controleerbare hash gaat op schijf."""
    if TOEGANG.exists():
        try:
            gegevens = json.loads(TOEGANG.read_text(encoding="utf-8"))
            if all(isinstance(gegevens.get(naam), str) for naam in ("zout", "code_hash")):
                return gegevens, None
        except (OSError, ValueError, json.JSONDecodeError):
            pass
    code = "MikaGPT-" + secrets.token_urlsafe(12)
    zout = secrets.token_hex(16)
    gegevens = {
        "zout": zout,
        "code_hash": hashlib.sha256((zout + code).encode("utf-8")).hexdigest(),
    }
    tijdelijk = TOEGANG.with_suffix(".tmp")
    tijdelijk.write_text(json.dumps(gegevens, indent=2), encoding="utf-8")
    tijdelijk.replace(TOEGANG)
    return gegevens, code


def versienummer(versie):
    """Vergelijk eenvoudige versies zoals 0.1.0 zonder extra pakket."""
    stukken = versie.split(".")
    if not stukken or any(not stuk.isdigit() for stuk in stukken):
        raise ValueError("Ongeldige versie")
    return tuple(int(stuk) for stuk in (stukken + ["0", "0", "0"])[:3])


def controleer_updates():
    """Lees alleen een kleine openbare updatebeschrijving, geen privédata."""
    if not UPDATECONFIG.exists():
        return {"huidige_versie": VERSIE, "update": False,
                "melding": "Er is nog geen online updatebron ingesteld."}
    try:
        instellingen = json.loads(UPDATECONFIG.read_text(encoding="utf-8"))
        adres = instellingen.get("update_adres", "")
        if not isinstance(adres, str) or not adres.startswith("https://"):
            raise ValueError
        verzoek = Request(adres, headers={"User-Agent": f"MikaGPT/{VERSIE}"})
        with UPDATEVERBINDING.open(verzoek, timeout=10) as reactie:
            info = json.load(reactie)
        nieuwste = info["versie"]
        download = info["download_url"]
        controlegetal = info["sha256"]
        if (not isinstance(nieuwste, str) or not isinstance(download, str)
                or not download.startswith("https://")
                or not isinstance(controlegetal, str)
                or len(controlegetal) != 64
                or any(teken not in "0123456789abcdefABCDEF" for teken in controlegetal)):
            raise ValueError
        beschikbaar = versienummer(nieuwste) > versienummer(VERSIE)
        return {"huidige_versie": VERSIE, "nieuwste_versie": nieuwste,
                "update": beschikbaar, "download_url": download if beschikbaar else "",
                "sha256": controlegetal.lower() if beschikbaar else "",
                "melding": "Er is een update beschikbaar." if beschikbaar else "Je hebt de nieuwste versie."}
    except (OSError, ValueError, KeyError, json.JSONDecodeError):
        return {"huidige_versie": VERSIE, "update": False,
                "melding": "Ik kon de updateinformatie niet ophalen."}


def start_installatie_van_update():
    """Download een gecontroleerde update.

    In de vaste runtime wordt alleen het payload-bestand vervangen. Daardoor
    komt er bij toekomstige updates geen nieuwe .exe op de computer.
    """
    info = controleer_updates()
    if not info.get("update"):
        raise ValueError(info.get("melding", "Er is geen update beschikbaar."))
    doel = DATAMAP / ".mikagpt-nieuwe-versie.zip"
    tijdelijk = doel.with_suffix(".tmp")
    try:
        verzoek = Request(info["download_url"], headers={"User-Agent": f"MikaGPT/{VERSIE}"})
        with UPDATEVERBINDING.open(verzoek, timeout=45) as reactie, tijdelijk.open("wb") as bestand:
            totaal = 0
            while True:
                deel = reactie.read(64 * 1024)
                if not deel:
                    break
                totaal += len(deel)
                if totaal > 500 * 1024 * 1024:
                    raise ValueError("De update is onverwacht groot.")
                bestand.write(deel)
        if hashlib.sha256(tijdelijk.read_bytes()).hexdigest().lower() != info["sha256"]:
            raise ValueError("De controle van de update is mislukt.")
        with zipfile.ZipFile(tijdelijk) as archief:
            namen = set(archief.namelist())
            if os.environ.get("MIKAGPT_STABLE_RUNTIME") == "1":
                verwacht = {"mikagpt_web.py", "mikagpt_web.html", "test AI Model.py", "mikagpt_features.py"}
            else:
                verwacht = {"MikaGPT.exe", "OPEN_MIKAGPT_WEBSITE.exe", "MikaGPTUpdater.exe", "LEESMIJ.txt", "mikagpt_update.json"}
            if not verwacht.issubset(namen) or any("/" in naam or "\\" in naam for naam in namen):
                raise ValueError("Dit is geen geldig MikaGPT-updatebestand.")
        tijdelijk.replace(doel)
        if os.environ.get("MIKAGPT_STABLE_RUNTIME") == "1":
            runtime = Path(sys.executable)
            opdracht = [str(runtime), "--installeer-payload", "--pid", str(os.getpid()),
                         "--zip", str(doel), "--map", str(DATAMAP)]
            # Bij testen met gewone Python moet het runtime-script expliciet mee.
            if not getattr(sys, "frozen", False):
                opdracht = [sys.executable, str(Path(os.environ["MIKAGPT_RUNTIME_SCRIPT"])), *opdracht[1:]]
            subprocess.Popen(opdracht, cwd=DATAMAP, close_fds=True)
        else:
            updater = DATAMAP / "MikaGPTUpdater.exe"
            if not updater.is_file():
                raise RuntimeError("De updatehulp ontbreekt. Download MikaGPT opnieuw.")
            subprocess.Popen([str(updater), "--pid", str(os.getpid()), "--zip", str(doel), "--map", str(DATAMAP)],
                             cwd=DATAMAP, close_fds=True)
    except Exception:
        tijdelijk.unlink(missing_ok=True)
        raise


TOEGANGSGEGEVENS, NIEUWE_TOEGANGSCODE = laad_toegang()


def wijzig_eigenaarscode(huidige_code, nieuwe_code):
    """Vervang de eigenaarscode nadat de huidige code is gecontroleerd."""
    global TOEGANGSGEGEVENS
    if not isinstance(huidige_code, str) or not isinstance(nieuwe_code, str):
        raise ValueError("Vul beide codes in.")
    if not 4 <= len(nieuwe_code) <= 128:
        raise ValueError("Je nieuwe eigenaarscode moet 4 tot 128 tekens hebben.")
    with EIGENAAR_SLOT:
        gekregen = hashlib.sha256((TOEGANGSGEGEVENS["zout"] + huidige_code).encode("utf-8")).hexdigest()
        if not hmac.compare_digest(gekregen, TOEGANGSGEGEVENS["code_hash"]):
            raise ValueError("Je huidige eigenaarscode klopt niet.")
        zout = secrets.token_hex(16)
        TOEGANGSGEGEVENS = {
            **TOEGANGSGEGEVENS,
            "zout": zout,
            "code_hash": hashlib.sha256((zout + nieuwe_code).encode("utf-8")).hexdigest(),
        }
        tijdelijk = TOEGANG.with_suffix(".tmp")
        tijdelijk.write_text(json.dumps(TOEGANGSGEGEVENS, indent=2), encoding="utf-8")
        tijdelijk.replace(TOEGANG)


LOGIN_HTML = """<!doctype html><html lang='nl'><meta charset='utf-8'>
<meta name='viewport' content='width=device-width,initial-scale=1'>
<title>Inloggen bij MikaGPT</title>
<style>:root{font-family:system-ui,sans-serif;color-scheme:dark;background:#10151f;color:#f4f7fc}*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:20px;background:radial-gradient(circle at top,#284968,#10151f 55%)}main{width:min(410px,100%);padding:30px;border:1px solid #49617d;border-radius:22px;background:#192233;box-shadow:0 24px 70px #0008}.logo{width:58px;height:58px;object-fit:cover;border-radius:18px;box-shadow:0 7px 20px #0c6bb888}h1{margin:16px 0 6px}p{color:#b7c5d8;line-height:1.5}label{display:block;margin-top:14px;font-weight:650}input,button{box-sizing:border-box;width:100%;font:inherit;padding:13px;border-radius:11px}input{margin-top:6px;border:1px solid #536783;background:#111a28;color:white}button{margin-top:18px;border:0;background:#4ac9e7;color:#071723;font-weight:800;cursor:pointer}.link,.gast{background:transparent;color:#d9efff;border:1px solid #536783}.verborgen{display:none}#fout{min-height:1.4em;color:#ffb4ab;font-weight:650}.klein{font-size:.88rem}</style>
<main><img class='logo' src='/logo.png' alt='MikaGPT-logo'><h1>Welkom bij MikaGPT</h1><p id='uitleg'>Log in om verder te gaan met jouw eigen MikaGPT.</p>
<form id='inloggen'><label>Gebruikersnaam<input id='naam' autocomplete='username' required maxlength='32'></label><label>Wachtwoord<input id='wachtwoord' type='password' autocomplete='current-password' required minlength='8' maxlength='128'></label><button>Inloggen</button></form>
<form id='accountmaken' class='verborgen'><label>Kies een gebruikersnaam<input id='nieuwe-naam' autocomplete='username' required maxlength='32' pattern='[A-Za-z0-9_-]+'></label><label>Kies een wachtwoord<input id='nieuw-wachtwoord' type='password' autocomplete='new-password' required minlength='8' maxlength='128'></label><button>Account maken</button></form>
<button class='link' id='wissel' type='button'>Heb je nog geen account? Maak er één</button><button class='gast' id='gast' type='button'>Zonder code inloggen</button><button class='link klein' id='eigenaar' type='button'>Inloggen met eigenaarscode</button><p id='fout'></p></main>
<script>const fout=document.getElementById('fout'),inloggen=document.getElementById('inloggen'),maken=document.getElementById('accountmaken'),wissel=document.getElementById('wissel');let nieuw=false;async function stuur(url,body){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});if(r.ok)location.reload();else{const d=await r.json().catch(()=>({}));fout.textContent=d.fout||'Dit lukte niet. Controleer je gegevens.'}}inloggen.onsubmit=e=>{e.preventDefault();stuur('/inloggen',{gebruikersnaam:naam.value,wachtwoord:wachtwoord.value})};maken.onsubmit=e=>{e.preventDefault();stuur('/account-maken',{gebruikersnaam:document.getElementById('nieuwe-naam').value,wachtwoord:document.getElementById('nieuw-wachtwoord').value})};wissel.onclick=()=>{nieuw=!nieuw;inloggen.classList.toggle('verborgen',nieuw);maken.classList.toggle('verborgen',!nieuw);wissel.textContent=nieuw?'Heb je al een account? Log in':'Heb je nog geen account? Maak er één';fout.textContent=''};document.getElementById('gast').onclick=()=>stuur('/zonder-code',{});document.getElementById('eigenaar').onclick=()=>{const code=prompt('Vul de eigenaarscode in:');if(code)stuur('/eigenaar',{code})};</script></html>""".encode("utf-8")


def maak_uitbundig(antwoord):
    """Geef korte webantwoorden meer kleur zonder de inhoud te veranderen."""
    if not antwoord.startswith("AI: ") or "\n" in antwoord:
        return antwoord
    tekst = antwoord[4:]
    klein = tekst.casefold()
    # Problemen en onzekerheden vragen om een rustige, duidelijke reactie.
    if any(stuk in klein for stuk in ("niet betrouwbaar", "weet ik niet", "nog niet", "kon niet",
                                      "fout", "ongeldig", "geannuleerd", "niet gelukt")):
        return antwoord
    if klein.startswith(("hoi", "hallo", "hey")):
        return antwoord + " 😄"
    if klein == "ik ben mikagpt.":
        return "AI: Ik ben MikaGPT! 😄 Leuk dat we kunnen praten."
    if klein == "met mij gaat het goed!":
        return "AI: Met mij gaat het goed, bedankt dat je het vraagt! 😄"
    if klein.startswith(("taak toegevoegd", "notitie bewaard", "ik heb geleerd", "leuk je te ontmoeten")):
        return "AI: " + random.choice(["Gelukt! 🎉 ", "Mooi, geregeld! ✨ "]) + tekst
    if klein.startswith(("prima", "oké", "leuk", "fijn om te horen", "graag gedaan")):
        return antwoord + " 😊"
    return antwoord


def normaliseer_gebruikersnaam(naam):
    """Sta alleen een korte, veilige naam toe voor een lokaal account."""
    if not isinstance(naam, str):
        raise ValueError("Vul een gebruikersnaam in.")
    naam = naam.strip().casefold()
    if not 3 <= len(naam) <= 32 or any(teken not in "abcdefghijklmnopqrstuvwxyz0123456789_-" for teken in naam):
        raise ValueError("Je gebruikersnaam heeft 3 tot 32 letters, cijfers, _ of - nodig.")
    return naam


def wachtwoord_hash(wachtwoord, zout):
    return hashlib.pbkdf2_hmac("sha256", wachtwoord.encode("utf-8"), bytes.fromhex(zout), 200_000).hex()


def laad_accounts():
    if not ACCOUNTS.exists():
        return {}
    try:
        gegevens = json.loads(ACCOUNTS.read_text(encoding="utf-8"))
        return gegevens if isinstance(gegevens, dict) else {}
    except (OSError, ValueError, json.JSONDecodeError):
        return {}


def bewaar_accounts(accounts):
    tijdelijk = ACCOUNTS.with_suffix(".tmp")
    tijdelijk.write_text(json.dumps(accounts, indent=2), encoding="utf-8")
    tijdelijk.replace(ACCOUNTS)


def maak_account(naam, wachtwoord):
    naam = normaliseer_gebruikersnaam(naam)
    if not isinstance(wachtwoord, str) or not 4 <= len(wachtwoord) <= 128:
        raise ValueError("Je wachtwoord moet minstens 4 tekens hebben.")
    with ACCOUNT_SLOT:
        accounts = laad_accounts()
        if naam in accounts:
            raise ValueError("Deze gebruikersnaam bestaat al.")
        zout = secrets.token_hex(16)
        accounts[naam] = {"zout": zout, "wachtwoord_hash": wachtwoord_hash(wachtwoord, zout)}
        bewaar_accounts(accounts)
    return naam


def controleer_account(naam, wachtwoord):
    try:
        naam = normaliseer_gebruikersnaam(naam)
    except ValueError:
        return None
    if not isinstance(wachtwoord, str):
        return None
    with ACCOUNT_SLOT:
        account = laad_accounts().get(naam)
    if not isinstance(account, dict) or not isinstance(account.get("zout"), str) or not isinstance(account.get("wachtwoord_hash"), str):
        return None
    gekregen = wachtwoord_hash(wachtwoord, account["zout"])
    return naam if hmac.compare_digest(gekregen, account["wachtwoord_hash"]) else None


def account_bestand(naam):
    """Geef de vaste, onleesbare bestandsnaam van de gegevens van één account."""
    veilig_deel = hashlib.sha256(naam.encode("utf-8")).hexdigest()[:16]
    return DATAMAP / f"mikagpt_account_{veilig_deel}.json"


def wijzig_account(oude_naam, huidig_wachtwoord, nieuwe_naam, nieuw_wachtwoord):
    """Werk accountgegevens bij en verhuis de privégegevens bij een naamswijziging."""
    if not controleer_account(oude_naam, huidig_wachtwoord):
        raise ValueError("Je huidige wachtwoord klopt niet.")
    nieuwe_naam = normaliseer_gebruikersnaam(nieuwe_naam)
    if nieuw_wachtwoord and (not isinstance(nieuw_wachtwoord, str) or not 4 <= len(nieuw_wachtwoord) <= 128):
        raise ValueError("Je nieuwe wachtwoord moet minstens 4 tekens hebben.")
    with ACCOUNT_SLOT:
        accounts = laad_accounts()
        account = accounts.get(oude_naam)
        if not isinstance(account, dict):
            raise ValueError("Dit account bestaat niet meer.")
        if nieuwe_naam != oude_naam and nieuwe_naam in accounts:
            raise ValueError("Deze gebruikersnaam bestaat al.")
        if nieuw_wachtwoord:
            zout = secrets.token_hex(16)
            account["zout"] = zout
            account["wachtwoord_hash"] = wachtwoord_hash(nieuw_wachtwoord, zout)
        if nieuwe_naam != oude_naam:
            oud_bestand, nieuw_bestand = account_bestand(oude_naam), account_bestand(nieuwe_naam)
            if oud_bestand.exists():
                oud_bestand.replace(nieuw_bestand)
            accounts[nieuwe_naam] = accounts.pop(oude_naam)
        bewaar_accounts(accounts)
    if nieuwe_naam != oude_naam:
        oud_proces = ACCOUNT_PROCESSEN.pop(oude_naam, None)
        if oud_proces:
            with oud_proces.slot:
                oud_proces._sluit()
    return nieuwe_naam


class MikaGPTProces:
    """Stuur één bericht tegelijk naar de bestaande terminalversie."""

    def __init__(self, gegevensbestand):
        self.proces = None
        self.tekens = queue.Queue()
        self.slot = threading.Lock()
        self.gegevensbestand = gegevensbestand

    def _lees_uitvoer(self, proces, tekens):
        while True:
            teken = proces.stdout.read(1)
            if not teken:
                tekens.put(None)
                return
            tekens.put(teken)

    def _lees_tot_prompt(self):
        uitvoer = ""
        while True:
            try:
                teken = self.tekens.get(timeout=120)
            except queue.Empty as fout:
                self._sluit()
                raise RuntimeError("MikaGPT reageert niet. Probeer het opnieuw.") from fout
            if teken is None:
                return uitvoer.strip(), True
            uitvoer += teken
            if uitvoer.endswith("Jij: "):
                return uitvoer[:-5].strip(), False
            if len(uitvoer) > 100_000:
                self._sluit()
                raise RuntimeError("Het antwoord van MikaGPT is te lang.")

    def _start(self):
        self.tekens = queue.Queue()
        omgeving = os.environ.copy()
        omgeving["PYTHONIOENCODING"] = "utf-8"
        omgeving["MIKAGPT_DATA_BESTAND"] = str(self.gegevensbestand)
        # De vaste runtime start zichzelf in terminalmodus. De oude losse
        # versie gebruikt nog MikaGPT.exe naast de website-exe.
        if os.environ.get("MIKAGPT_STABLE_RUNTIME") == "1":
            if getattr(sys, "frozen", False):
                opdracht = [sys.executable, "--terminal"]
            else:
                opdracht = [sys.executable, os.environ["MIKAGPT_RUNTIME_SCRIPT"], "--terminal"]
        elif getattr(sys, "frozen", False):
            programma = Path(sys.executable).with_name("MikaGPT.exe")
            if not programma.is_file():
                raise RuntimeError("MikaGPT.exe staat niet naast MikaGPTWebsite.exe.")
            opdracht = [str(programma)]
        else:
            opdracht = [sys.executable, "-u", str(SCRIPT)]
        self.proces = subprocess.Popen(
            opdracht,
            cwd=DATAMAP,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            env=omgeving,
        )
        threading.Thread(target=self._lees_uitvoer, args=(self.proces, self.tekens), daemon=True).start()
        antwoord, gestopt = self._lees_tot_prompt()
        if gestopt:
            raise RuntimeError(antwoord or "MikaGPT kon niet starten.")
        return antwoord

    def nieuwe_sessie(self):
        """Laat de welkomsttekst en de echte gespreksstatus weer overeenkomen."""
        with self.slot:
            self._sluit()
            return self._start()

    def _sluit(self):
        if self.proces is not None and self.proces.poll() is None:
            self.proces.terminate()
        self.proces = None

    def vraag(self, bericht):
        with self.slot:
            if self.proces is None or self.proces.poll() is not None:
                self._start()
            try:
                self.proces.stdin.write(bericht + "\n")
                self.proces.stdin.flush()
                antwoord, gestopt = self._lees_tot_prompt()
            except (BrokenPipeError, OSError):
                self._sluit()
                raise RuntimeError("De verbinding met MikaGPT is verbroken.")
            if gestopt:
                self._sluit()
            return antwoord, gestopt


MIKAGPT_EIGENAAR = MikaGPTProces(DATAMAP / "mikagpt_data.json")
MIKAGPT_GAST = MikaGPTProces(DATAMAP / "mikagpt_gast_data.json")


def proces_voor_account(naam):
    """Elk account gebruikt een eigen bestand voor chat, taken en geheugen."""
    with ACCOUNT_SLOT:
        if naam not in ACCOUNT_PROCESSEN:
            ACCOUNT_PROCESSEN[naam] = MikaGPTProces(account_bestand(naam))
        return ACCOUNT_PROCESSEN[naam]


class WebVerzoek(BaseHTTPRequestHandler):
    def _antwoord(self, code, inhoud, soort="application/json; charset=utf-8", extra_headers=None):
        self.send_response(code)
        self.send_header("Content-Type", soort)
        self.send_header("Content-Length", str(len(inhoud)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for naam, waarde in (extra_headers or {}).items():
            self.send_header(naam, waarde)
        origin = self.headers.get("Origin")
        if origin in TOEGESTANE_ORIGINS:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.end_headers()
        self.wfile.write(inhoud)

    def _sessie(self):
        cookies = self.headers.get("Cookie", "")
        code = next((deel.split("=", 1)[1] for deel in cookies.split(";")
                     if deel.strip().startswith("mikagpt_sessie=")), "")
        sessie = SESSIES.get(code)
        if isinstance(sessie, dict):
            return sessie
        SESSIES.pop(code, None)
        return None

    def _aangemeld(self):
        return self._sessie() is not None

    def _proces(self):
        sessie = self._sessie()
        if not sessie:
            return MIKAGPT_GAST
        if sessie.get("rol") == "eigenaar":
            return MIKAGPT_EIGENAAR
        if sessie.get("rol") == "account":
            return proces_voor_account(sessie["account"])
        return MIKAGPT_GAST

    def _maak_sessie(self, rol, account=None):
        sessie = secrets.token_urlsafe(32)
        SESSIES[sessie] = {"rol": rol, "account": account}
        secure = "; Secure" if self.headers.get("X-Forwarded-Proto") == "https" else ""
        cookie = f"mikagpt_sessie={sessie}; HttpOnly; SameSite=Strict; Path=/{secure}"
        self._antwoord(200, json.dumps({"klaar": True, "rol": rol}).encode("utf-8"),
                       extra_headers={"Set-Cookie": cookie})

    def _verwijder_sessie(self):
        """Verwijder de huidige sessie wanneer het MikaGPT-tabblad sluit."""
        cookies = self.headers.get("Cookie", "")
        code = next((deel.split("=", 1)[1] for deel in cookies.split(";")
                     if deel.strip().startswith("mikagpt_sessie=")), "")
        SESSIES.pop(code, None)

    def _zelfde_website(self):
        """Sta alleen dezelfde website toe; de tunnel krijgt een andere hostnaam."""
        oorsprong = self.headers.get("Origin")
        if not oorsprong:
            return True
        try:
            return urlsplit(oorsprong).netloc == self.headers.get("Host")
        except ValueError:
            return False

    def do_OPTIONS(self):
        if self.path not in {"/bericht", "/status"} or not self._zelfde_website():
            self.send_error(403)
            return
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin", ""))
        self.send_header("Access-Control-Allow-Methods", "POST" if self.path == "/bericht" else "GET")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Vary", "Origin")
        self.end_headers()

    def do_GET(self):
        if self.path == "/logo.png":
            if not LOGO.is_file():
                self.send_error(404)
                return
            self._antwoord(200, LOGO.read_bytes(), "image/png")
            return
        if self.path == "/":
            if not self._aangemeld():
                self._antwoord(200, LOGIN_HTML, "text/html; charset=utf-8")
                return
            self._antwoord(200, HTML.read_bytes(), "text/html; charset=utf-8")
            return
        if self.path == "/status":
            if not self._aangemeld() or not self._zelfde_website():
                self.send_error(403)
                return
            self._antwoord(200, b'{"klaar":true}')
            return
        if self.path == "/profiel":
            sessie = self._sessie()
            if not sessie or not self._zelfde_website():
                self.send_error(403)
                return
            instellingen = {}
            if sessie.get("rol") == "account":
                with ACCOUNT_SLOT:
                    account = laad_accounts().get(sessie.get("account"), {})
                if isinstance(account, dict) and isinstance(account.get("instellingen"), dict):
                    instellingen = account["instellingen"]
            elif sessie.get("rol") == "eigenaar":
                with EIGENAAR_SLOT:
                    if isinstance(TOEGANGSGEGEVENS.get("instellingen"), dict):
                        instellingen = TOEGANGSGEGEVENS["instellingen"]
            resultaat = {"rol": sessie.get("rol"), "account": sessie.get("account"), "instellingen": instellingen}
            self._antwoord(200, json.dumps(resultaat, ensure_ascii=False).encode("utf-8"))
            return
        if self.path == "/overzicht":
            if not self._aangemeld() or not self._zelfde_website():
                self.send_error(403)
                return
            try:
                bestand = self._proces().gegevensbestand
                gegevens = json.loads(bestand.read_text(encoding="utf-8")) if bestand.exists() else {}
                actief = gegevens.get("actief_project", "Algemeen")
                project = gegevens.get("projecten", {}).get(actief, {})
                taken = project.get("taken", gegevens.get("taken", []))
                if not isinstance(taken, list):
                    taken = []
                projecten = []
                for naam, item in gegevens.get("projecten", {}).items():
                    if not isinstance(item, dict):
                        continue
                    regels = item.get("gesprek", [])
                    chats = []
                    for nummer, regel in enumerate(regels):
                        if (isinstance(regel, dict) and isinstance(regel.get("vraag"), str)
                                and isinstance(regel.get("antwoord"), str)):
                            chats.append({"id": nummer, "vraag": regel["vraag"],
                                          "antwoord": regel["antwoord"],
                                          "titel": regel.get("titel", regel["vraag"]),
                                          "vastgezet": bool(regel.get("vastgezet", False))})
                    chats = chats[-20:]
                    project_taken = item.get("taken", [])
                    project_notities = item.get("notities", [])
                    projecten.append({"naam": naam, "actief": naam == actief, "chats": chats,
                                      "taken": project_taken if isinstance(project_taken, list) else [],
                                      "notities": project_notities if isinstance(project_notities, list) else []})
                voorkeuren = gegevens.get("voorkeuren", [])
                if not isinstance(voorkeuren, list):
                    voorkeuren = []
                resultaat = {"project": actief, "taken": taken, "projecten": projecten,
                             "geheugen": [feit for feit in voorkeuren if isinstance(feit, str)]}
                self._antwoord(200, json.dumps(resultaat, ensure_ascii=False).encode("utf-8"))
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                self._antwoord(200, b'{"project":"Algemeen","taken":[]}')
            return
        if self.path == "/bestanden":
            if not self._aangemeld() or not self._zelfde_website():
                self.send_error(403)
                return
            try:
                proces = self._proces()
                with proces.slot:
                    gegevens = json.loads(proces.gegevensbestand.read_text(encoding="utf-8")) if proces.gegevensbestand.exists() else {}
                    project = gegevens.get("actief_project", "Algemeen")
                    veilige_projectnaam = re.sub(r"[^\w-]", "_", project, flags=re.UNICODE)
                    mapje = DATAMAP / "projecten" / veilige_projectnaam
                    bestanden = []
                    if mapje.exists():
                        for pad in sorted(mapje.iterdir(), key=lambda item: item.name.casefold()):
                            if pad.is_file() and pad.suffix.lower() in TOEGESTANE_BESTANDEN:
                                bestanden.append({"naam": pad.name, "grootte": pad.stat().st_size,
                                                  "type": pad.suffix.lower().lstrip(".")})
                self._antwoord(200, json.dumps({"project": project, "bestanden": bestanden}, ensure_ascii=False).encode("utf-8"))
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                self._antwoord(200, b'{"project":"Algemeen","bestanden":[]}')
            return
        if self.path == "/taskmanager":
            if not self._aangemeld() or not self._zelfde_website():
                self.send_error(403)
                return
            try:
                opdracht = (
                    "$os=Get-CimInstance Win32_OperatingSystem;"
                    "$cs=Get-CimInstance Win32_ComputerSystem;"
                    "$cpu=[math]::Round((Get-CimInstance Win32_Processor | Measure-Object LoadPercentage -Average).Average,1);"
                    "$aantal=(Get-Process).Count;"
                    "[PSCustomObject]@{cpu=$cpu;"
                    "geheugen=[math]::Round((1-($os.FreePhysicalMemory/$os.TotalVisibleMemorySize))*100,1);"
                    "totaal_geheugen=$cs.TotalPhysicalMemory;processen=$aantal}|ConvertTo-Json -Compress -Depth 3"
                )
                uitvoer = subprocess.check_output(
                    ["powershell", "-NoProfile", "-NonInteractive", "-Command", opdracht],
                    text=True, encoding="utf-8", errors="replace", timeout=12,
                )
                self._antwoord(200, uitvoer.encode("utf-8"))
            except (OSError, subprocess.SubprocessError, ValueError):
                self._antwoord(503, b'{"fout":"Systeemgegevens laden lukte niet."}')
            return
        if self.path == "/update":
            if not self._aangemeld() or not self._zelfde_website():
                self.send_error(403)
                return
            self._antwoord(200, json.dumps(controleer_updates(), ensure_ascii=False).encode("utf-8"))
            return
        if self.path == "/agenda":
            if not self._aangemeld() or not self._zelfde_website():
                self.send_error(403)
                return
            try:
                proces = self._proces()
                with proces.slot:
                    gegevens = json.loads(proces.gegevensbestand.read_text(encoding="utf-8")) if proces.gegevensbestand.exists() else {}
                    afspraken = gegevens.get("afspraken", [])
                    overzicht = []
                    if isinstance(afspraken, list):
                        for nummer, item in enumerate(afspraken):
                            if not isinstance(item, dict):
                                continue
                            moment, tekst, soort = item.get("moment"), item.get("tekst"), item.get("soort")
                            if isinstance(moment, str) and isinstance(tekst, str) and soort in {"afspraak", "herinnering"}:
                                try:
                                    datetime.fromisoformat(moment)
                                except ValueError:
                                    continue
                                overzicht.append({"id": nummer, "moment": moment, "tekst": tekst,
                                                  "soort": soort, "gemeld": bool(item.get("gemeld"))})
                    overzicht.sort(key=lambda item: item["moment"])
                self._antwoord(200, json.dumps({"afspraken": overzicht}, ensure_ascii=False).encode("utf-8"))
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                self._antwoord(200, b'{"afspraken":[]}')
            return
        if self.path == "/herinneringen":
            if not self._aangemeld() or not self._zelfde_website():
                self.send_error(403)
                return
            try:
                proces = self._proces()
                with proces.slot:
                    gegevens = json.loads(proces.gegevensbestand.read_text(encoding="utf-8")) if proces.gegevensbestand.exists() else {}
                    afspraken = gegevens.get("afspraken", [])
                    if not isinstance(afspraken, list):
                        afspraken = []
                    meldingen = []
                    gewijzigd = False
                    nu = datetime.now()
                    for nummer, item in enumerate(afspraken):
                        if not isinstance(item, dict):
                            continue
                        if item.get("soort") == "herinnering" and not item.get("gemeld"):
                            try:
                                if datetime.fromisoformat(item.get("moment", "")) <= nu:
                                    meldingen.append(item.get("tekst", "Herinnering"))
                                    item["gemeld"] = True
                                    gewijzigd = True
                            except (TypeError, ValueError):
                                continue
                    if gewijzigd:
                        tijdelijk = proces.gegevensbestand.with_suffix(".tmp")
                        tijdelijk.write_text(json.dumps(gegevens, ensure_ascii=False, indent=2), encoding="utf-8")
                        tijdelijk.replace(proces.gegevensbestand)
                    overzicht = []
                    for nummer, item in enumerate(afspraken):
                        if isinstance(item, dict) and item.get("soort") == "herinnering":
                            overzicht.append({"id": nummer, "moment": item.get("moment", ""), "tekst": item.get("tekst", ""), "gemeld": bool(item.get("gemeld"))})
                    overzicht.sort(key=lambda item: item["moment"])
                self._antwoord(200, json.dumps({"herinneringen": overzicht, "meldingen": meldingen}, ensure_ascii=False).encode("utf-8"))
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                self._antwoord(200, b'{"herinneringen":[],"meldingen":[]}')
            return
        self.send_error(404)

    def do_POST(self):
        if self.path not in {"/bericht", "/sessie", "/inloggen", "/account-maken", "/eigenaar", "/zonder-code", "/uitloggen", "/update/installeren", "/chat-beheer", "/project-beheer", "/geheugen-beheer", "/taken-beheer", "/notities-beheer", "/bestand-upload", "/bestand-verwijder", "/profiel-beheer", "/herinneringen-beheer", "/agenda-beheer"}:
            self.send_error(404)
            return
        if not self._zelfde_website():
            self.send_error(403)
            return
        try:
            if self.path == "/agenda-beheer":
                if not self._aangemeld():
                    self.send_error(403)
                    return
                lengte = int(self.headers.get("Content-Length", "0"))
                if not 1 <= lengte <= 3000:
                    self.send_error(400)
                    return
                data = json.loads(self.rfile.read(lengte))
                actie = data.get("actie")
                if actie not in {"toevoegen", "wijzig", "verwijder"}:
                    self.send_error(400)
                    return
                proces = self._proces()
                with proces.slot:
                    proces._sluit()
                    bestand = proces.gegevensbestand
                    gegevens = json.loads(bestand.read_text(encoding="utf-8")) if bestand.exists() else {}
                    afspraken = gegevens.setdefault("afspraken", [])
                    if not isinstance(afspraken, list):
                        self.send_error(400)
                        return
                    if actie == "toevoegen":
                        tekst = data.get("tekst", "").strip() if isinstance(data.get("tekst"), str) else ""
                        moment_tekst = data.get("moment", "") if isinstance(data.get("moment"), str) else ""
                        soort = data.get("soort", "afspraak")
                        try:
                            moment = datetime.fromisoformat(moment_tekst)
                        except ValueError:
                            self._antwoord(400, b'{"fout":"Kies een geldige datum en tijd."}')
                            return
                        if not 1 <= len(tekst) <= 300 or soort not in {"afspraak", "herinnering"}:
                            self._antwoord(400, b'{"fout":"Vul een afspraak van maximaal 300 tekens in."}')
                            return
                        item = {"moment": moment.isoformat(timespec="minutes"), "tekst": tekst, "soort": soort}
                        afspraken.append(item)
                    else:
                        nummer = data.get("id")
                        if not isinstance(nummer, int) or not 0 <= nummer < len(afspraken) or not isinstance(afspraken[nummer], dict):
                            self._antwoord(404, b'{"fout":"Afspraak niet gevonden."}')
                            return
                        if actie == "verwijder":
                            afspraken.pop(nummer)
                        else:
                            tekst = data.get("tekst", "").strip() if isinstance(data.get("tekst"), str) else ""
                            moment_tekst = data.get("moment", "") if isinstance(data.get("moment"), str) else ""
                            soort = data.get("soort", "afspraak")
                            try:
                                moment = datetime.fromisoformat(moment_tekst)
                            except ValueError:
                                self._antwoord(400, b'{"fout":"Kies een geldige datum en tijd."}')
                                return
                            if not 1 <= len(tekst) <= 300 or soort not in {"afspraak", "herinnering"}:
                                self._antwoord(400, b'{"fout":"Vul een geldige afspraak in."}')
                                return
                            afspraken[nummer].update({"moment": moment.isoformat(timespec="minutes"), "tekst": tekst, "soort": soort})
                            afspraken[nummer].pop("gemeld", None)
                    tijdelijk = bestand.with_suffix(".tmp")
                    tijdelijk.write_text(json.dumps(gegevens, ensure_ascii=False, indent=2), encoding="utf-8")
                    tijdelijk.replace(bestand)
                self._antwoord(200, b'{"klaar":true}')
                return
            if self.path == "/herinneringen-beheer":
                if not self._aangemeld():
                    self.send_error(403)
                    return
                lengte = int(self.headers.get("Content-Length", "0"))
                if not 1 <= lengte <= 512:
                    self.send_error(400)
                    return
                data = json.loads(self.rfile.read(lengte))
                if data.get("actie") != "verwijder" or not isinstance(data.get("id"), int):
                    self.send_error(400)
                    return
                proces = self._proces()
                with proces.slot:
                    proces._sluit()
                    gegevens = json.loads(proces.gegevensbestand.read_text(encoding="utf-8")) if proces.gegevensbestand.exists() else {}
                    afspraken = gegevens.get("afspraken", [])
                    nummer = data["id"]
                    if not isinstance(afspraken, list) or not 0 <= nummer < len(afspraken) or afspraken[nummer].get("soort") != "herinnering":
                        self.send_error(404)
                        return
                    afspraken.pop(nummer)
                    tijdelijk = proces.gegevensbestand.with_suffix(".tmp")
                    tijdelijk.write_text(json.dumps(gegevens, ensure_ascii=False, indent=2), encoding="utf-8")
                    tijdelijk.replace(proces.gegevensbestand)
                self._antwoord(200, b'{"klaar":true}')
                return
            if self.path == "/profiel-beheer":
                sessie = self._sessie()
                if not sessie or sessie.get("rol") not in {"account", "eigenaar"}:
                    self._antwoord(403, b'{"fout":"Log in met een account of als eigenaar om je profiel te wijzigen."}')
                    return
                lengte = int(self.headers.get("Content-Length", "0"))
                if not 1 <= lengte <= 1024:
                    self.send_error(400)
                    return
                data = json.loads(self.rfile.read(lengte))
                actie = data.get("actie")
                if actie == "instellingen":
                    uitbundig, antwoordlengte = data.get("uitbundig"), data.get("antwoordlengte")
                    if not isinstance(uitbundig, bool) or antwoordlengte not in {"kort", "normaal", "uitgebreid"}:
                        self.send_error(400)
                        return
                    if sessie.get("rol") == "eigenaar":
                        with EIGENAAR_SLOT:
                            TOEGANGSGEGEVENS["instellingen"] = {"uitbundig": uitbundig, "antwoordlengte": antwoordlengte}
                            tijdelijk = TOEGANG.with_suffix(".tmp")
                            tijdelijk.write_text(json.dumps(TOEGANGSGEGEVENS, indent=2), encoding="utf-8")
                            tijdelijk.replace(TOEGANG)
                    else:
                        with ACCOUNT_SLOT:
                            accounts = laad_accounts()
                            account = accounts.get(sessie["account"])
                            if not isinstance(account, dict):
                                self.send_error(404)
                                return
                            account["instellingen"] = {"uitbundig": uitbundig, "antwoordlengte": antwoordlengte}
                            bewaar_accounts(accounts)
                    self._antwoord(200, b'{"klaar":true}')
                    return
                if actie == "eigenaarscode":
                    if sessie.get("rol") != "eigenaar":
                        self.send_error(403)
                        return
                    try:
                        wijzig_eigenaarscode(data.get("huidige_code"), data.get("nieuwe_code"))
                    except ValueError as fout:
                        self._antwoord(400, json.dumps({"fout": str(fout)}, ensure_ascii=False).encode("utf-8"))
                        return
                    self._antwoord(200, b'{"klaar":true}')
                    return
                if actie != "gegevens":
                    self.send_error(400)
                    return
                try:
                    naam = wijzig_account(
                        sessie["account"], data.get("huidig_wachtwoord"),
                        data.get("gebruikersnaam"), data.get("nieuw_wachtwoord", ""),
                    )
                except ValueError as fout:
                    self._antwoord(400, json.dumps({"fout": str(fout)}, ensure_ascii=False).encode("utf-8"))
                    return
                sessie["account"] = naam
                self._antwoord(200, json.dumps({"klaar": True, "account": naam}, ensure_ascii=False).encode("utf-8"))
                return
            if self.path == "/bestand-verwijder":
                if not self._aangemeld():
                    self.send_error(403)
                    return
                lengte = int(self.headers.get("Content-Length", "0"))
                if not 1 <= lengte <= 512:
                    self.send_error(400)
                    return
                data = json.loads(self.rfile.read(lengte))
                naam = data.get("naam")
                if not isinstance(naam, str) or Path(naam).name != naam or not naam.strip():
                    self.send_error(400)
                    return
                proces = self._proces()
                with proces.slot:
                    proces._sluit()
                    gegevens = json.loads(proces.gegevensbestand.read_text(encoding="utf-8")) if proces.gegevensbestand.exists() else {}
                    project = gegevens.get("actief_project", "Algemeen")
                    veilige_projectnaam = re.sub(r"[^\w-]", "_", project, flags=re.UNICODE)
                    pad = (DATAMAP / "projecten" / veilige_projectnaam / naam).resolve()
                    basis = (DATAMAP / "projecten" / veilige_projectnaam).resolve()
                    if not pad.is_relative_to(basis) or not pad.is_file():
                        self._antwoord(404, b'{"fout":"Bestand niet gevonden."}')
                        return
                    pad.unlink()
                self._antwoord(200, json.dumps({"verwijderd": naam}, ensure_ascii=False).encode("utf-8"))
                return
            if self.path == "/bestand-upload":
                if not self._aangemeld():
                    self.send_error(403)
                    return
                lengte = int(self.headers.get("Content-Length", "0"))
                if not 1 <= lengte <= MAX_UPLOAD * 2:
                    self.send_error(413)
                    return
                data = json.loads(self.rfile.read(lengte))
                naam = data.get("naam", "")
                inhoud = data.get("inhoud", "")
                if (not isinstance(naam, str) or not isinstance(inhoud, str)
                        or Path(naam).name != naam or not naam.strip()):
                    self.send_error(400)
                    return
                naam = re.sub(r"[^\w. -]", "_", naam.strip(), flags=re.UNICODE)
                extensie = Path(naam).suffix.lower()
                if extensie not in TOEGESTANE_BESTANDEN:
                    self._antwoord(400, b'{"fout":"Kies een tekst-, code-, PDF- of afbeeldingsbestand."}')
                    return
                try:
                    bytes_inhoud = base64.b64decode(inhoud, validate=True)
                except (ValueError, TypeError):
                    self.send_error(400)
                    return
                if len(bytes_inhoud) > MAX_UPLOAD:
                    self._antwoord(413, b'{"fout":"Dit bestand is groter dan 2 MB."}')
                    return
                proces = self._proces()
                with proces.slot:
                    proces._sluit()
                    gegevens = json.loads(proces.gegevensbestand.read_text(encoding="utf-8")) if proces.gegevensbestand.exists() else {}
                    project = gegevens.get("actief_project", "Algemeen")
                    veilige_projectnaam = re.sub(r"[^\w-]", "_", project, flags=re.UNICODE)
                    mapje = DATAMAP / "projecten" / veilige_projectnaam
                    mapje.mkdir(parents=True, exist_ok=True)
                    doel = mapje / naam
                    nummer = 2
                    while doel.exists():
                        doel = mapje / f"{Path(naam).stem} ({nummer}){extensie}"
                        nummer += 1
                    doel.write_bytes(bytes_inhoud)
                self._antwoord(200, json.dumps({"naam": doel.name, "project": project}, ensure_ascii=False).encode("utf-8"))
                return
            if self.path == "/notities-beheer":
                if not self._aangemeld():
                    self.send_error(403)
                    return
                lengte = int(self.headers.get("Content-Length", "0"))
                if not 1 <= lengte <= 6000:
                    self.send_error(400)
                    return
                data = json.loads(self.rfile.read(lengte))
                actie = data.get("actie")
                if actie not in {"toevoegen", "wijzig", "verwijder", "verplaats"}:
                    self.send_error(400)
                    return
                proces = self._proces()
                with proces.slot:
                    proces._sluit()
                    bestand = proces.gegevensbestand
                    gegevens = json.loads(bestand.read_text(encoding="utf-8")) if bestand.exists() else {}
                    projecten = gegevens.get("projecten", {})
                    if not isinstance(projecten, dict):
                        self.send_error(400)
                        return
                    actief = gegevens.get("actief_project", "Algemeen")
                    bron_naam = data.get("project", actief) if isinstance(data.get("project", actief), str) else actief
                    bron = projecten.get(bron_naam)
                    if not isinstance(bron, dict):
                        self.send_error(404)
                        return
                    notities = bron.setdefault("notities", [])
                    if not isinstance(notities, list):
                        self.send_error(400)
                        return
                    # Oude tekstnotities worden ook hier veilig leesbaar gemaakt.
                    for index, item in enumerate(notities):
                        if isinstance(item, str):
                            inhoud = item.strip()
                            notities[index] = {"titel": inhoud.splitlines()[0][:60], "inhoud": inhoud}
                    if actie == "toevoegen":
                        inhoud = data.get("inhoud", "").strip() if isinstance(data.get("inhoud"), str) else ""
                        titel = data.get("titel", "").strip() if isinstance(data.get("titel"), str) else ""
                        if not inhoud or len(inhoud) > 4000:
                            self._antwoord(400, b'{"fout":"Schrijf een notitie van 1 tot 4000 tekens."}')
                            return
                        notities.append({"titel": (titel or inhoud.splitlines()[0])[:60], "inhoud": inhoud})
                    else:
                        nummer = data.get("id")
                        if not isinstance(nummer, int) or not 0 <= nummer < len(notities) or not isinstance(notities[nummer], dict):
                            self.send_error(404)
                            return
                        if actie == "verwijder":
                            notities.pop(nummer)
                        elif actie == "wijzig":
                            titel = data.get("titel", "").strip() if isinstance(data.get("titel"), str) else ""
                            inhoud = data.get("inhoud", "").strip() if isinstance(data.get("inhoud"), str) else ""
                            if not titel or len(titel) > 60 or not inhoud or len(inhoud) > 4000:
                                self._antwoord(400, b'{"fout":"Titel moet 1 tot 60 tekens zijn en inhoud 1 tot 4000 tekens."}')
                                return
                            notities[nummer] = {"titel": titel, "inhoud": inhoud}
                        else:
                            doel_naam = data.get("doel_project")
                            doel = projecten.get(doel_naam) if isinstance(doel_naam, str) else None
                            if not isinstance(doel, dict):
                                self._antwoord(400, b'{"fout":"Kies een bestaand project."}')
                                return
                            doel_notities = doel.setdefault("notities", [])
                            if not isinstance(doel_notities, list):
                                self.send_error(400)
                                return
                            doel_notities.append(notities.pop(nummer))
                    tijdelijk = bestand.with_suffix(".tmp")
                    tijdelijk.write_text(json.dumps(gegevens, ensure_ascii=False, indent=2), encoding="utf-8")
                    tijdelijk.replace(bestand)
                self._antwoord(200, b'{"klaar":true}')
                return
            if self.path == "/taken-beheer":
                if not self._aangemeld():
                    self.send_error(403)
                    return
                lengte = int(self.headers.get("Content-Length", "0"))
                if not 1 <= lengte <= 512:
                    self.send_error(400)
                    return
                data = json.loads(self.rfile.read(lengte))
                actie = data.get("actie")
                proces = self._proces()
                with proces.slot:
                    proces._sluit()
                    bestand = proces.gegevensbestand
                    gegevens = json.loads(bestand.read_text(encoding="utf-8")) if bestand.exists() else {}
                    actief = gegevens.get("actief_project", "Algemeen")
                    project = gegevens.get("projecten", {}).get(actief)
                    if not isinstance(project, dict):
                        self.send_error(400)
                        return
                    taken = project.setdefault("taken", [])
                    if not isinstance(taken, list):
                        self.send_error(400)
                        return
                    if actie == "toevoegen":
                        tekst = data.get("tekst", "").strip() if isinstance(data.get("tekst"), str) else ""
                        if not 1 <= len(tekst) <= 300:
                            self._antwoord(400, b'{"fout":"Schrijf een taak van 1 tot 300 tekens."}')
                            return
                        taken.append({"tekst": tekst, "klaar": False})
                    elif actie in {"wissel", "verwijder"}:
                        nummer = data.get("id")
                        if not isinstance(nummer, int) or not 0 <= nummer < len(taken):
                            self.send_error(404)
                            return
                        if actie == "wissel":
                            taken[nummer]["klaar"] = not bool(taken[nummer].get("klaar", False))
                        else:
                            taken.pop(nummer)
                    else:
                        self.send_error(400)
                        return
                    tijdelijk = bestand.with_suffix(".tmp")
                    tijdelijk.write_text(json.dumps(gegevens, ensure_ascii=False, indent=2), encoding="utf-8")
                    tijdelijk.replace(bestand)
                self._antwoord(200, b'{"klaar":true}')
                return
            if self.path == "/geheugen-beheer":
                if not self._aangemeld():
                    self.send_error(403)
                    return
                lengte = int(self.headers.get("Content-Length", "0"))
                if not 1 <= lengte <= 512:
                    self.send_error(400)
                    return
                data = json.loads(self.rfile.read(lengte))
                actie = data.get("actie")
                proces = self._proces()
                with proces.slot:
                    proces._sluit()
                    bestand = proces.gegevensbestand
                    gegevens = json.loads(bestand.read_text(encoding="utf-8")) if bestand.exists() else {}
                    voorkeuren = gegevens.setdefault("voorkeuren", [])
                    if not isinstance(voorkeuren, list):
                        self.send_error(400)
                        return
                    if actie == "toevoegen":
                        tekst = data.get("tekst", "").strip() if isinstance(data.get("tekst"), str) else ""
                        if not 1 <= len(tekst) <= 300:
                            self._antwoord(400, b'{"fout":"Schrijf een herinnering van 1 tot 300 tekens."}')
                            return
                        voorkeuren.append(tekst)
                    elif actie == "verwijder":
                        nummer = data.get("id")
                        if not isinstance(nummer, int) or not 0 <= nummer < len(voorkeuren):
                            self.send_error(404)
                            return
                        voorkeuren.pop(nummer)
                    else:
                        self.send_error(400)
                        return
                    tijdelijk = bestand.with_suffix(".tmp")
                    tijdelijk.write_text(json.dumps(gegevens, ensure_ascii=False, indent=2), encoding="utf-8")
                    tijdelijk.replace(bestand)
                self._antwoord(200, b'{"klaar":true}')
                return
            if self.path == "/project-beheer":
                if not self._aangemeld():
                    self.send_error(403)
                    return
                lengte = int(self.headers.get("Content-Length", "0"))
                if not 1 <= lengte <= 512:
                    self.send_error(400)
                    return
                data = json.loads(self.rfile.read(lengte))
                actie, naam = data.get("actie"), data.get("naam")
                if actie not in {"verwijder", "hernoem"} or not isinstance(naam, str):
                    self.send_error(400)
                    return
                proces = self._proces()
                with proces.slot:
                    proces._sluit()
                    bestand = proces.gegevensbestand
                    gegevens = json.loads(bestand.read_text(encoding="utf-8")) if bestand.exists() else {}
                    projecten = gegevens.get("projecten", {})
                    if naam == "Algemeen" or naam not in projecten:
                        self._antwoord(400, b'{"fout":"Dit project kan niet worden aangepast."}')
                        return
                    if actie == "verwijder":
                        del projecten[naam]
                        if gegevens.get("actief_project") == naam:
                            gegevens["actief_project"] = "Algemeen"
                    else:
                        nieuwe_naam = data.get("nieuwe_naam", "").strip() if isinstance(data.get("nieuwe_naam"), str) else ""
                        if not 1 <= len(nieuwe_naam) <= 60 or nieuwe_naam in projecten:
                            self._antwoord(400, b'{"fout":"Kies een unieke projectnaam van 1 tot 60 tekens."}')
                            return
                        projecten[nieuwe_naam] = projecten.pop(naam)
                        if gegevens.get("actief_project") == naam:
                            gegevens["actief_project"] = nieuwe_naam
                    tijdelijk = bestand.with_suffix(".tmp")
                    tijdelijk.write_text(json.dumps(gegevens, ensure_ascii=False, indent=2), encoding="utf-8")
                    tijdelijk.replace(bestand)
                self._antwoord(200, b'{"klaar":true}')
                return
            if self.path == "/chat-beheer":
                if not self._aangemeld():
                    self.send_error(403)
                    return
                lengte = int(self.headers.get("Content-Length", "0"))
                if not 1 <= lengte <= 512:
                    self.send_error(400)
                    return
                data = json.loads(self.rfile.read(lengte))
                actie, nummer = data.get("actie"), data.get("id")
                if actie == "wis-algemene-chats":
                    proces = self._proces()
                    with proces.slot:
                        proces._sluit()
                        bestand = proces.gegevensbestand
                        gegevens = json.loads(bestand.read_text(encoding="utf-8")) if bestand.exists() else {}
                        algemeen = gegevens.get("projecten", {}).get("Algemeen", {})
                        if not isinstance(algemeen, dict):
                            self.send_error(400)
                            return
                        algemeen["gesprek"] = []
                        tijdelijk = bestand.with_suffix(".tmp")
                        tijdelijk.write_text(json.dumps(gegevens, ensure_ascii=False, indent=2), encoding="utf-8")
                        tijdelijk.replace(bestand)
                    self._antwoord(200, b'{"klaar":true}')
                    return
                if actie not in {"verwijder", "hernoem", "vastzetten"} or not isinstance(nummer, int):
                    self.send_error(400)
                    return
                proces = self._proces()
                with proces.slot:
                    proces._sluit()
                    bestand = proces.gegevensbestand
                    gegevens = json.loads(bestand.read_text(encoding="utf-8")) if bestand.exists() else {}
                    actief = gegevens.get("actief_project", "Algemeen")
                    regels = gegevens.get("projecten", {}).get(actief, {}).get("gesprek", [])
                    if not isinstance(regels, list) or not 0 <= nummer < len(regels) or not isinstance(regels[nummer], dict):
                        self.send_error(404)
                        return
                    if actie == "verwijder":
                        regels.pop(nummer)
                    elif actie == "vastzetten":
                        regels[nummer]["vastgezet"] = not bool(regels[nummer].get("vastgezet", False))
                    else:
                        titel = data.get("titel", "").strip() if isinstance(data.get("titel"), str) else ""
                        if not 1 <= len(titel) <= 80:
                            self._antwoord(400, b'{"fout":"De chatnaam moet 1 tot 80 tekens hebben."}')
                            return
                        regels[nummer]["titel"] = titel
                    tijdelijk = bestand.with_suffix(".tmp")
                    tijdelijk.write_text(json.dumps(gegevens, ensure_ascii=False, indent=2), encoding="utf-8")
                    tijdelijk.replace(bestand)
                self._antwoord(200, b'{"klaar":true}')
                return
            if self.path == "/update/installeren":
                if not self._aangemeld():
                    self.send_error(403)
                    return
                try:
                    start_installatie_van_update()
                except (OSError, ValueError, RuntimeError) as fout:
                    self._antwoord(400, json.dumps({"fout": str(fout)}, ensure_ascii=False).encode("utf-8"))
                    return
                self._antwoord(202, b'{"melding":"De update is gecontroleerd. MikaGPT sluit nu en start straks opnieuw."}')
                threading.Timer(1.0, lambda: os._exit(0)).start()
                return
            if self.path in {"/inloggen", "/account-maken", "/eigenaar"}:
                lengte = int(self.headers.get("Content-Length", "0"))
                if not 1 <= lengte <= 1024:
                    self.send_error(400)
                    return
                gegevens = json.loads(self.rfile.read(lengte))
                if not isinstance(gegevens, dict):
                    self.send_error(400)
                    return
                if self.path == "/account-maken":
                    try:
                        account = maak_account(gegevens.get("gebruikersnaam"), gegevens.get("wachtwoord"))
                    except ValueError as fout:
                        self._antwoord(400, json.dumps({"fout": str(fout)}, ensure_ascii=False).encode("utf-8"))
                        return
                    self._maak_sessie("account", account)
                    return
                if self.path == "/inloggen":
                    account = controleer_account(gegevens.get("gebruikersnaam"), gegevens.get("wachtwoord"))
                    if not account:
                        self._antwoord(401, b'{"fout":"Gebruikersnaam of wachtwoord klopt niet."}')
                        return
                    self._maak_sessie("account", account)
                    return
                code = gegevens.get("code", "")
                if not isinstance(code, str):
                    self.send_error(400)
                    return
                verwacht = TOEGANGSGEGEVENS["code_hash"]
                gekregen = hashlib.sha256((TOEGANGSGEGEVENS["zout"] + code).encode("utf-8")).hexdigest()
                if not hmac.compare_digest(gekregen, verwacht):
                    self.send_error(401)
                    return
                self._maak_sessie("eigenaar")
                return
            if self.path == "/zonder-code":
                self._maak_sessie("gast")
                return
            if self.path == "/uitloggen":
                self._verwijder_sessie()
                verlopen_cookie = "mikagpt_sessie=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"
                self._antwoord(204, b"", extra_headers={"Set-Cookie": verlopen_cookie})
                return
            if not self._aangemeld():
                self.send_error(401)
                return
            if self.path == "/sessie":
                antwoord = self._proces().nieuwe_sessie()
                self._antwoord(200, json.dumps({"antwoord": antwoord}, ensure_ascii=False).encode("utf-8"))
                return
            lengte = int(self.headers.get("Content-Length", "0"))
            if lengte < 1 or lengte > 4096:
                self.send_error(413)
                return
            data = json.loads(self.rfile.read(lengte))
            bericht = data.get("bericht")
            uitbundig = data.get("uitbundig", True)
            if (not isinstance(bericht, str) or not bericht.strip() or len(bericht) > 1000
                    or not isinstance(uitbundig, bool)):
                self.send_error(400)
                return
            antwoord, gestopt = self._proces().vraag(bericht.strip())
            if uitbundig and not gestopt:
                antwoord = maak_uitbundig(antwoord)
            resultaat = {"antwoord": antwoord, "gestopt": gestopt}
            self._antwoord(200, json.dumps(resultaat, ensure_ascii=False).encode("utf-8"))
        except (json.JSONDecodeError, ValueError, TypeError):
            self.send_error(400)
        except RuntimeError as fout:
            self._antwoord(500, json.dumps({"fout": str(fout)}, ensure_ascii=False).encode("utf-8"))


def main():
    server = ThreadingHTTPServer((HOST, PORT), WebVerzoek)
    if NIEUWE_TOEGANGSCODE:
        print("Jouw nieuwe MikaGPT-toegangscode (bewaar deze goed):")
        print(NIEUWE_TOEGANGSCODE)
    print(f"MikaGPT staat klaar op {ADRES}")
    print("Laat dit venster open zolang je de website gebruikt. Druk Ctrl+C om te stoppen.")
    if not os.environ.get("MIKAGPT_NO_BROWSER"):
        webbrowser.open(ADRES)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        MIKAGPT_EIGENAAR._sluit()
        MIKAGPT_GAST._sluit()
        for proces in ACCOUNT_PROCESSEN.values():
            proces._sluit()


if __name__ == "__main__":
    main()
